<?php if(isset($bill)): ?>
    <?php $__env->startSection('title', 'Редактировать ' . $bill->title); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Добавить'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(isset($bill)): ?>
                        <h1>Редактировать <?php echo e($bill->title); ?></h1>
                    <?php else: ?>
                        <h1>Добавить</h1>
                    <?php endif; ?>
                    <form method="post" enctype="multipart/form-data"
                          <?php if(isset($bill)): ?>
                              action="<?php echo e(route('bills.update', $bill)); ?>"
                          <?php else: ?>
                              action="<?php echo e(route('bills.store')); ?>"
                            <?php endif; ?>
                    >
                        <?php if(isset($bill)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input type="hidden" value="<?php echo e($hotel); ?>" name="hotel_id">
                        <div class="form-group">
                            <label for="">Заголовок</label>
                            <input type="text" name="title" value="<?php echo e(old('title', isset($bill) ? $bill->title :
                             null)); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Дата</label>
                            <input type="date" name="date" value="<?php echo e(old('date', isset($bill) ? $bill->date :
                             null)); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Файл</label>
                            <input type="file" name="file1">
                        </div>
                            <div class="form-group">
                                <label for="">Файл #2</label>
                                <input type="file" name="file2">
                            </div>
                        <div class="form-group">
                            <label for="">Статус</label>
                            <select name="status">
                                <?php if(isset($bill)): ?>
                                    <?php if($bill->status == 1): ?>
                                        <option value="<?php echo e($bill->status); ?>">Активный</option>
                                        <option value="0">Не заключен</option>
                                    <?php else: ?>
                                        <option value="<?php echo e($bill->status); ?>">Не заключен</option>
                                        <option value="1">Актвиный</option>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <option value="1">Активный</option>
                                    <option value="0">Не заключен</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <?php echo csrf_field(); ?>
                        <button class="more">Отправить</button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/bills/form.blade.php ENDPATH**/ ?>