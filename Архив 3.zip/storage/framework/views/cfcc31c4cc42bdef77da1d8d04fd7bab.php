<?php if(isset($user)): ?>
    <?php $__env->startSection('title', 'Редактировать пользователя' . $user->name); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Создать пользователя'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(isset($user)): ?>
                        <h1>Редактировать пользователя <?php echo e($user->title); ?></h1>
                    <?php else: ?>
                        <h1>Создать пользователя</h1>
                    <?php endif; ?>
                    <form method="post"
                          <?php if(isset($user)): ?>
                              action="<?php echo e(route('manager.users.update', $user)); ?>"
                          <?php else: ?>
                              action="<?php echo e(route('manager.users.store')); ?>"
                            <?php endif; ?>
                    >
                        <?php if(isset($user)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-group">
                            <label for="name">ФИО</label>
                            <input type="text" name="name" id="name" value="<?php echo e(old('name', isset($user) ? $user->name :
                             null)); ?>">
                        </div>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" name="email" id="email" value="<?php echo e(old('email', isset($user) ?
                                $user->email : null)); ?>">
                        </div>
                        <?php if(isset($user)): ?>
                        <?php else: ?>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="form-group">
                                <label for="password">Пароль</label>
                                <input type="password" name="password" id="password" value="<?php echo e(old('password', isset
                            ($user) ?
                                $user->password : null)); ?>">
                                <div class="checkbox">
                                    <input type="checkbox" id="checkbox"><label for="checkbox">Показать пароль</label>
                                </div>
                                <script src="https://code.jquery.com/jquery-3.7.1.min.js"
                                        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="
                                        crossorigin="anonymous"></script>
                                <script>
                                    $(document).ready(function () {
                                        $('#checkbox').on('change', function () {
                                            $('#password').attr('type', $('#checkbox').prop('checked') == true ? "text" : "password");
                                        });
                                    });
                                </script>

                                <style>
                                    .checkbox {
                                        margin-top: 10px;
                                    }

                                    .checkbox label {
                                        display: inline-block;
                                    }
                                </style>
                            </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <label for="role">Роль пользователя</label>
                            <select name="is_admin" id="role">
                                <?php if(isset($user)): ?>
                                    <option value="<?php echo e($user->is_admin); ?>">
                                        <?php if($user->is_admin == 1): ?>
                                            Администратор
                                        <?php elseif($user->is_admin == 2): ?>
                                            Менеджер
                                        <?php elseif($user->is_admin == 3): ?>
                                            Бухгалтер
                                        <?php elseif($user->is_admin == 4): ?>
                                            Менеджер Отеля
                                        <?php else: ?>
                                            Пользователь
                                        <?php endif; ?>
                                    </option>
                                <?php else: ?>
                                    <option>Выбрать</option>
                                <?php endif; ?>
                                <option value="1">Администратор</option>
                                <option value="2">Менеджер</option>
                                <option value="3">Бухгалтер</option>
                                <option value="4">Менеджер Отеля</option>
                            </select>
                        </div>
                        <?php echo csrf_field(); ?>
                        <button class="more">Отправить</button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/manager/users/form.blade.php ENDPATH**/ ?>