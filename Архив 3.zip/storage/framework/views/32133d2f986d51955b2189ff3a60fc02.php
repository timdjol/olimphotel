<?php $__env->startSection('title', 'Бронирование'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin bookings">
        <div class="container">
            <div class="row">
                <div class="col-md-12">































                    <h1>Брони</h1>
                    <table>
                        <tr>
                            <th>Бронь</th>
                            <th>Гость</th>
                            <th>Номер</th>
                            <th>Дата</th>
                            <th>Стоимость</th>
                        </tr>
                        <tbody>
                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="title"># <?php echo e($booking->id); ?></div>
                                    <div class="stick">B2B</div>
                                    <div class="date">Создано <?php echo e($booking->created_at); ?></div>
                                </td>
                                <td>
                                    <div class="title"><?php echo e($booking->title); ?></div>
                                    <div class="count"><?php echo e($booking->count); ?> взрос.</div>
                                    <?php if($booking->countc > 0): ?>
                                        <div class="count"><?php echo e($booking->countc); ?> дет.</div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                        $room = \App\Models\Room::where('id', $booking->room_id)->firstOrFail();
                                    ?>
                                    <div class="title"><?php echo e($room->title); ?></div>
                                </td>
                                <td><?php echo e($booking->showStartDate()); ?> - <?php echo e($booking->showEndDate()); ?></td>
                                <td>
                                    <div class="title"><?php echo e($booking->sum); ?></div>
                                    <div class="status"><i class="fa-regular fa-money-bill"></i> Оплачено</div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/listbooks/index.blade.php ENDPATH**/ ?>