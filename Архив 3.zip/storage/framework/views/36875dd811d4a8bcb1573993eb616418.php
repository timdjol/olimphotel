<?php $__env->startSection('title', 'Отели'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin mainhotels">
        <div class="container">
            <?php if(session()->has('success')): ?>
                <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
            <?php endif; ?>
            <?php if(session()->has('warning')): ?>
                <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-6">
                    <form action="">
                        <input type="search" value="<?php echo e($s_query ?? ''); ?>" placeholder="Поиск...">
                    </form>
                </div>
                <div class="col-md-3">
                    <div class="add">
                        <a href="<?php echo e(route('hotels.create')); ?>" class="more"><i class="fa-regular fa-plus"></i>
                            Добавить недвижимость</a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table>
                        <tr>
                            <th>Наименование</th>
                            <th>Адрес</th>
                            <th>Действия</th>
                        </tr>
                        <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($hotel->title); ?></td>
                            <td><?php echo e($hotel->address); ?></td>
                            <td>
                                <a href="<?php echo e(route('hotels.show', $hotel)); ?>" class="more"><i class="fa-regular fa-pen-to-square"></i> Выбрать</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php echo e($hotels->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"
            integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>

    <script>
        function submit_post_filter() {
            let appUrl = <?php echo json_encode(url('/admin/')); ?>;
            let s_query = $('#s_query').val();
            let show_item_at_once = $('#show_item_at_once').val();
            let ch_status = $('#ch_status').val();
            console.log(show_item_at_once);

            if (s_query != '') {
                s_query = s_query;
            } else {
                s_query = '0';
            }

            if (show_item_at_once != '0') {
                show_item_at_once = show_item_at_once;
            } else if (show_item_at_once == '0') {
                show_item_at_once = 0;
            } else {
                show_item_at_once = 'all';
            }

            if (ch_status != '') {
                ch_status = ch_status;
            } else {
                ch_status = '3';
            }


            window.location.href = appUrl + '/hotels/' + ch_status + '/' + show_item_at_once + '/' +
                s_query;
        }

        $(document).ready(function () {
            $('#filter_btn').click(function () {
                submit_post_filter();
            });

        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/hotels/index.blade.php ENDPATH**/ ?>