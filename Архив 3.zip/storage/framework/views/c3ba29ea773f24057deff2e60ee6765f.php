<div class="sidebar">
    <ul>
        <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
            <li <?php echo Route::currentRouteNamed('hotels.show') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('hotels.show', $hotel)); ?>"><i class="fas fa-gauge"></i>
            Информация</a></li>
            <li <?php echo Route::currentRouteNamed('services.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('services.index')); ?>"><i class="fa-regular
            fa-bell-concierge"></i> Удобства и услуги</a></li>
            <li <?php echo Route::currentRouteNamed('payments.index') ? 'class="current"' : ''  ?>>
            <a href="<?php echo e(route('payments.index')); ?>"><i class="fa-regular fa-money-bill"></i> Способы оплаты</a>
            </li>
            <li <?php echo Route::currentRouteNamed('policies.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('policies.index')); ?>"><i class="fa-regular fa-key"></i>
            Политика</a></li>


        <?php endif; ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('manager')): ?>
            <li <?php echo Route::currentRouteNamed('manager.dashboard') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('manager.dashboard')); ?>"><i class="fas
            fa-gauge"></i> Консоль</a></li>
            <li <?php echo Route::currentRouteNamed('manager.books.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('manager.books.index')); ?>"><i class="fas
            fa-calendar"></i> Бронирование</a></li>
            <li <?php echo Route::currentRouteNamed('manager.hotels.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('manager.hotels.index')); ?>"><i class="fas
            fa-hotel"></i> Отели</a></li>
            <li <?php echo Route::currentRouteNamed('manager.rooms.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('manager.rooms.index')); ?>"><i class="fas
            fa-booth-curtain"></i> Номера</a></li>
            <li <?php echo Route::currentRouteNamed('manager.users.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('manager.users.index')); ?>"><i class="fas
            fa-user"></i> Пользователи</a></li>
            <li <?php echo Route::currentRouteNamed('manager.pages.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('manager.pages.index')); ?>"><i class="fas
            fa-page"></i> Страницы</a></li>
            <li <?php echo Route::currentRouteNamed('manager.contacts.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('manager.contacts.index')); ?>"><i class="fas
            fa-address-book"></i> Контакты</a></li>
            <li><a href="<?php echo e(route('profile.edit')); ?>"><i class="fas
            fa-address-card"></i> Профиль</a></li>
        <?php endif; ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('buh')): ?>
            <li <?php echo Route::currentRouteNamed('buh.dashboard') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('buh.dashboard')); ?>"><i class="fas fa-gauge"></i>
            Консоль</a></li>
            <li <?php echo Route::currentRouteNamed('buh.books.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('buh.books.index')); ?>"><i class="fas
            fa-calendar"></i> Бронирование</a></li>
            <li <?php echo Route::currentRouteNamed('buh.hotels.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('buh.hotels.index')); ?>"><i class="fas
            fa-hotel"></i> Отели</a></li>
            <li <?php echo Route::currentRouteNamed('buh.rooms.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('buh.rooms.index')); ?>"><i class="fas
            fa-booth-curtain"></i> Номера</a></li>
            <li><a href="<?php echo e(route('profile.edit')); ?>"><i class="fas
            fa-address-card"></i> Профиль</a></li>
        <?php endif; ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('hotel')): ?>
            <li <?php echo Route::currentRouteNamed('hotel.dashboard') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('hotel.dashboard')); ?>"><i class="fas fa-gauge"></i>
            Консоль</a></li>
            <li <?php echo Route::currentRouteNamed('hotel.books.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('hotel.books.index')); ?>"><i class="fas
            fa-calendar"></i> Бронирование</a></li>
            <li <?php echo Route::currentRouteNamed('hotel.hotels.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('hotel.hotels.index')); ?>"><i class="fas
            fa-hotel"></i> Отели</a></li>
            <li <?php echo Route::currentRouteNamed('hotel.rooms.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('hotel.rooms.index')); ?>"><i class="fas
            fa-booth-curtain"></i> Номера</a></li>
            <li><a href="<?php echo e(route('profile.edit')); ?>"><i class="fas
            fa-address-card"></i> Профиль</a></li>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/layouts/sidebar.blade.php ENDPATH**/ ?>