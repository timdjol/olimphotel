<?php $__env->startSection('title', 'Отель ' . $hotel->title); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <h1><?php echo e($hotel->title); ?></h1>
                    <table class="table">
                        <tr>
                            <td>Название EN</td>
                            <td><?php echo e($hotel->title_en); ?></td>
                        </tr>
                        <tr>
                            <td>Описание</td>
                            <td><?php echo $hotel->description; ?></td>
                        </tr>
                        <tr>
                            <td>Описание EN</td>
                            <td><?php echo $hotel->description_en; ?></td>
                        </tr>
                        <tr>
                            <td>Стоимость завтрака</td>
                            <td><?php echo e($hotel->breakfast); ?> сом</td>
                        </tr>
                        <tr>
                            <td>Время заезда</td>
                            <td><?php echo e($hotel->checkin); ?></td>
                        </tr>
                        <tr>
                            <td>Время выезда</td>
                            <td><?php echo e($hotel->checkout); ?></td>
                        </tr>
                        <tr>
                            <td>Номер телефона</td>
                            <td><?php echo e($hotel->phone); ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><?php echo e($hotel->email); ?></td>
                        </tr>
                        <tr>
                            <td>Адрес</td>
                            <td><?php echo e($hotel->address); ?></td>
                        </tr>
                        <tr>
                            <td>Изображение</td>
                            <td><img src="<?php echo e(Storage::url($hotel->image)); ?>"></td>
                        </tr>
                    </table>
                    <script src="https://maps.api.2gis.ru/2.0/loader.js"></script>
                    <div id="map" style="width: 100%; height: 500px;"></div>
                    <script>
                        DG.then(function () {
                            var map = DG.map('map', {
                                center: [<?php echo e($hotel->lat); ?>, <?php echo e($hotel->lng); ?>],
                                zoom: 16
                            });

                            DG.marker([<?php echo e($hotel->lat); ?>, <?php echo e($hotel->lng); ?>], { scrollWheelZoom: false })
                                .addTo(map)
                                .bindLabel('<?php echo e($hotel->title); ?>', {
                                    static: true
                                });
                        });
                    </script>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/hotel/hotels/show.blade.php ENDPATH**/ ?>