<?php $__env->startSection('title', 'Главная'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin dashboard">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth/layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(session()->has('success')): ?>
                        <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
                    <?php endif; ?>
                    <?php if(session()->has('warning')): ?>
                        <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="sliders">
                                <h2>Слайды</h2>
                                <p>Количество слайдов: <?php echo e($sliders->count()); ?></p>
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>Изображение</th>
                                        <th>Название</th>
                                        <th>Действия</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><img src="<?php echo e(Storage::url($slider->image)); ?>" alt=""></td>
                                            <td><?php echo e($slider->title); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('sliders.destroy', $slider)); ?>" method="post">
                                                    <ul>
                                                        <li><a class="btn edit" href="<?php echo e(route('sliders.edit', $slider)); ?>"><i class="fa-regular fa-pen-to-square"></i></a></li>
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="btn delete"><i class="fa-regular fa-trash"></i></button>
                                                    </ul>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <a class="btn add" href="<?php echo e(route('sliders.create')); ?>"><i class="fa-solid
                                fa-plus"></i> Добавить слайд</a>
                                <?php echo e($sliders->links('pagination::bootstrap-4')); ?>

                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/home.blade.php ENDPATH**/ ?>