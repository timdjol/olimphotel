<?php $__env->startSection('title', 'Отели'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(session()->has('success')): ?>
                        <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
                    <?php endif; ?>
                    <?php if(session()->has('warning')): ?>
                        <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
                    <?php endif; ?>
                    <h1>Отели</h1>

                    <table class="table">
                        <thead>
                        <tr>
                            <th>Изображение</th>
                            <th>Название</th>
                            <th>Действия</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td><img src="<?php echo e(Storage::url($hotel->image)); ?>" alt="" width="100px"></td>
                            <td><?php echo e($hotel->title); ?></td>
                            <td>
                                <ul>
                                    <li><a class="btn view" href="<?php echo e(route('hotel.hotels.show', $hotel)); ?>"><i class="fa-regular fa-eye"></i></a></li>
                                    <li><a class="btn edit" href="<?php echo e(route('hotel.hotels.edit', $hotel)); ?>"><i class="fa-regular fa-pen-to-square"></i></a></li>
                                </ul>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/hotel/hotels/index.blade.php ENDPATH**/ ?>