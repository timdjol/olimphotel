<?php if(isset($hotel)): ?>
    <?php $__env->startSection('title', 'Редактировать отель ' . $hotel->title); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Добавить отель'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <?php if(isset($hotel)): ?>
                        <h1>Редактировать отель <?php echo e($hotel->title); ?></h1>
                    <?php else: ?>
                        <h1>Добавить отель</h1>
                    <?php endif; ?>
                    <form method="post" enctype="multipart/form-data"
                          <?php if(isset($hotel)): ?>
                              action="<?php echo e(route('hotels.update', $hotel)); ?>"
                          <?php else: ?>
                              action="<?php echo e(route('hotels.store')); ?>"
                            <?php endif; ?>
                    >
                        <?php if(isset($hotel)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-group">
                            <label for="">Заголовок</label>
                            <input type="text" name="title" value="<?php echo e(old('title', isset($hotel) ? $hotel->title :
                             null)); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Заголовок EN</label>
                            <input type="text" name="title_en" value="<?php echo e(old('title_en', isset($hotel) ?
                                $hotel->title_en :
                             null)); ?>">
                        </div>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Описание</label>
                            <textarea name="description" id="editor" rows="3"><?php echo e(old('description', isset($hotel) ?
                            $hotel->description : null)); ?></textarea>
                        </div>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'description_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Описание EN</label>
                            <textarea name="description_en" id="editor1" rows="3"><?php echo e(old('description_en', isset
                            ($hotel) ?
                            $hotel->description_en : null)); ?></textarea>
                        </div>
                        <script src="https://cdn.tiny.cloud/1/yxonqgmruy7kchzsv4uizqanbapq2uta96cs0p4y91ov9iod/tinymce/6/tinymce.min.js"
                                referrerpolicy="origin"></script>
                        <script src="https://cdn.ckeditor.com/ckeditor5/35.1.0/classic/ckeditor.js"></script>
                        <script>
                            ClassicEditor
                                .create(document.querySelector('#editor'))
                                .catch(error => {
                                    console.error(error);
                                });
                            ClassicEditor
                                .create(document.querySelector('#editor1'))
                                .catch(error => {
                                    console.error(error);
                                });
                        </script>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'breakfast'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Время заезда</label>
                                    <select name="checkin" id="">
                                        <?php if(isset($hotel)): ?>
                                            <option <?php if($hotel->checkin): ?>
                                                        selected>
                                                <?php echo e($hotel->checkin); ?></option>
                                        <?php else: ?>
                                            <option>Выбрать</option>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                        <option value="13:00">13:00</option>
                                        <option value="14:00">14:00</option>
                                        <option value="15:00">15:00</option>
                                        <option value="16:00">16:00</option>
                                        <option value="17:00">17:00</option>
                                        <option value="18:00">18:00</option>
                                        <option value="19:00">19:00</option>
                                        <option value="20:00">20:00</option>
                                        <option value="21:00">21:00</option>
                                        <option value="22:00">22:00</option>
                                        <option value="23:00">23:00</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Время выезда</label>
                                    <select name="checkout" id="">
                                        <?php if(isset($hotel)): ?>
                                            <option <?php if($hotel->checkout): ?>
                                                        selected>
                                                <?php echo e($hotel->checkout); ?></option>
                                        <?php else: ?>
                                            <option>Выбрать</option>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                        <option value="01:00">01:00</option>
                                        <option value="02:00">02:00</option>
                                        <option value="03:00">03:00</option>
                                        <option value="04:00">04:00</option>
                                        <option value="05:00">05:00</option>
                                        <option value="06:00">06:00</option>
                                        <option value="07:00">07:00</option>
                                        <option value="08:00">08:00</option>
                                        <option value="09:00">09:00</option>
                                        <option value="10:00">10:00</option>
                                        <option value="11:00">11:00</option>
                                        <option value="12:00">12:00</option>
                                        <option value="13:00">13:00</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Стоимость завтрака</label>
                                    <input type="number" name="breakfast" value="<?php echo e(old('breakfast', isset($hotel) ?
                                $hotel->breakfast : null)); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'phone'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="form-group">
                                    <label for="">Номер телефона</label>
                                    <input type="text" name="phone" value="<?php echo e(old('phone', isset($hotel) ? $hotel->phone :
                             null)); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="form-group">
                                    <label for="">Адрес</label>
                                    <input type="text" name="address" value="<?php echo e(old('address', isset($hotel) ?
                                $hotel->address : null)); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'address_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="form-group">
                                    <label for="">Адрес EN</label>
                                    <input type="text" name="address_en" value="<?php echo e(old('address_en', isset($hotel) ?
                                $hotel->address_en : null)); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'lat'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="form-group">
                                    <label for="">Широта</label>
                                    <input type="text" name="lat" value="<?php echo e(old('lat', isset($hotel) ?
                                $hotel->lat : null)); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'lng'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="form-group">
                                    <label for="">Долгота</label>
                                    <input type="text" name="lng" value="<?php echo e(old('lng', isset($hotel) ?
                                $hotel->lng : null)); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="form-group">
                                    <label for="">Email</label>
                                    <input type="email" name="email" value="<?php echo e(old('email', isset($hotel) ? $hotel->email :
                             null)); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'count'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="form-group">
                                    <label for="">Кол-во номеров</label>
                                    <input type="number" name="count" value="<?php echo e(old('count', isset($hotel) ?
                                    $hotel->count : null)); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'type'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="form-group">
                                    <label for="">Тип недвижимости</label>
                                    <input type="text" name="type" value="<?php echo e(old('type', isset($hotel) ?
                                    $hotel->type : null)); ?>">
                                </div>
                            </div>
                        </div>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'image'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Изображение</label>
                            <?php if(isset($hotel->image)): ?>
                                <img src="<?php echo e(Storage::url($hotel->image)); ?>" alt="">
                            <?php endif; ?>
                            <input type="file" name="image">
                        </div>
                        <div class="form-group">
                            <label for="">Статус</label>
                            <select name="status">
                                <?php if(isset($hotel)): ?>
                                    <?php if($hotel->status == 1): ?>
                                        <option value="<?php echo e($hotel->status); ?>">Включено</option>
                                        <option value="0">Отключено</option>
                                    <?php else: ?>
                                        <option value="<?php echo e($hotel->status); ?>">Включено</option>
                                        <option value="1">Включено</option>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <option value="1">Включено</option>
                                    <option value="0">Отключено</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <?php echo csrf_field(); ?>
                        <button class="more">Отправить</button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/hotels/form.blade.php ENDPATH**/ ?>