<?php $__env->startSection('title', 'Способы оплаты'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <h1>Политика</h1>
                    <?php if(!$policies->isEmpty()): ?>
                    <table>
                        <tr>
                            <th>Ранний въезд</th>
                            <th>Поздний выезд</th>
                            <th>Доп место</th>
                            <th>Наценка</th>
                            <th>Действия</th>
                        </tr>
                        <?php $__currentLoopData = $policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($policy->checkin); ?></td>
                                <td><?php echo e($policy->checkout); ?></td>
                                <td><?php echo e($policy->extra); ?></td>
                                <td><?php echo e($policy->amount); ?></td>
                                <td><a href="<?php echo e(route('policies.edit', $policy)); ?>" class="more"><i class="fa-regular
                                fa-pen-to-square"></i></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php else: ?>
                        <div class="btn-wrap" style="margin-top: 20px">
                            <a href="<?php echo e(route('policies.create')); ?>" class="more">Добавить</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/policies/index.blade.php ENDPATH**/ ?>