<?php $__env->startSection('title', $room->__('title')); ?>

<?php $__env->startSection('content'); ?>

    <div class="page rooms single">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="fotorama" data-allowfullscreen="true" data-nav="thumbs" data-loop="true"
                         data-autoplay="3000">
                        <img loading="lazy" src="<?php echo e(Storage::url($room->image)); ?>" alt="">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img loading="lazy" src="<?php echo e(Storage::url($image->image)); ?>" alt="">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="cont">
                        <script src="https://maps.api.2gis.ru/2.0/loader.js"></script>
                        <div id="map" style="width: 100%; height: 300px;"></div>
                        <script>
                            DG.then(function () {
                                var map = DG.map('map', {
                                    center: [<?php echo e($room->hotel->lat); ?>, <?php echo e($room->hotel->lng); ?>],
                                    zoom: 14
                                });

                                DG.marker([<?php echo e($room->hotel->lat); ?>, <?php echo e($room->hotel->lng); ?>], {scrollWheelZoom: false})
                                    .addTo(map)
                                    .bindLabel('<?php echo e($room->hotel->__('title')); ?>', {
                                        static: true
                                    });
                            });
                        </script>
                        <div class="phone"><span><?php echo app('translator')->get('main.hphone'); ?></span> <a href="tel:<?php echo e($room->hotel->phone); ?>"><?php echo e($room->hotel->phone); ?></a></div>
                        <div class="address"><span><?php echo app('translator')->get('main.address'); ?></span> <?php echo e($room->hotel->__('address')); ?></div>
                    </div>
                </div>
                <div class="col-md-6" data-aos="fade-left" data-aos-duration="2000">
                    <h1><?php echo e($room->__('title')); ?></h1>
                    <div class="price"><?php echo app('translator')->get('main.price'); ?> <?php echo e($room->price); ?> <?php echo app('translator')->get('main.som'); ?></div>
                    <div class="btn-wrap">
                        <a href="<?php echo e(route('books.index', $room->id)); ?>" class="more"><?php echo app('translator')->get('main.book'); ?></a>
                        <?php if(session('locale')=='ru'): ?>
                            <a href="https://api.whatsapp.com/send?phone=<?php echo e($room->hotel->phone); ?>&text=Заявка
                        на номер <?php echo e($room->__('title')); ?>" class="more whatsapp"
                               target="_blank"><?php echo app('translator')->get('main.book_whatsapp'); ?></a>
                        <?php else: ?>
                            <a href="https://api.whatsapp.com/send?phone=<?php echo e($room->hotel->phone); ?>&text=Booking room <?php echo e($room->__('title')); ?>"
                               class="more whatsapp"
                               target="_blank"><?php echo app('translator')->get('main.book_whatsapp'); ?></a>
                        <?php endif; ?>
                    </div>
                    <?php echo $room->__('description'); ?>

                    <div class="servlisting">
                        <ul>
                            <?php if($room->isTv()): ?>
                                <li><a href="#" class="tooltip"><img
                                                src="<?php echo e(url('/')); ?>/img/tv.png"><span><?php echo app('translator')->get('main.tv'); ?></span></a></li>
                            <?php endif; ?>
                            <?php if($room->isCloset()): ?>
                                <li><a href="#" class="tooltip"><img
                                                src="<?php echo e(url('/')); ?>/img/closet.png"><span><?php echo app('translator')->get('main.closet'); ?></span></a>
                                </li>
                            <?php endif; ?>
                            <?php if($room->isSafe()): ?>
                                <li><a href="#" class="tooltip"><img
                                                src="<?php echo e(url('/')); ?>/img/security-box.png"><span><?php echo app('translator')->get('main.safe'); ?></span></a>
                                </li>
                            <?php endif; ?>
                            <?php if($room->isBar()): ?>
                                <li><a href="#" class="tooltip"><img
                                                src="<?php echo e(url('/')); ?>/img/minibar.png"><span><?php echo app('translator')->get('main.bar'); ?></span></a>
                                </li>
                            <?php endif; ?>
                            <?php if($room->isCond()): ?>
                                <li><a href="#" class="tooltip"><img
                                                src="<?php echo e(url('/')); ?>/img/air-conditioner.png"><span><?php echo app('translator')->get('main.cond'); ?></span></a>
                                </li>
                            <?php endif; ?>
                            <?php if($room->isCabinet()): ?>
                                <li><a href="#" class="tooltip"><img
                                                src="<?php echo e(url('/')); ?>/img/bedside.png"><span><?php echo app('translator')->get('main.cabinet'); ?></span></a>
                                </li>
                            <?php endif; ?>
                            <?php if($room->isWtable()): ?>
                                <li><a href="#" class="tooltip"><img
                                                src="<?php echo e(url('/')); ?>/img/desk.png"><span><?php echo app('translator')->get('main.wtable'); ?></span></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="share">
                        <div class="descr"><?php echo app('translator')->get('main.share'); ?></div>
                        <script src="https://yastatic.net/share2/share.js"></script>
                        <div class="ya-share2" data-curtain data-shape="round"
                             data-services="vkontakte,odnoklassniki,telegram,twitter,whatsapp,linkedin"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if($related->isNotEmpty()): ?>
        <div class="page rooms related">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2><?php echo app('translator')->get('main.related'); ?></h2>
                    </div>
                </div>
                <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('layouts.card', compact('room'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/pages/room.blade.php ENDPATH**/ ?>