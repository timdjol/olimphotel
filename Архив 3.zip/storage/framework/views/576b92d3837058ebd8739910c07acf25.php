<?php $__env->startSection('title', 'Способы оплаты'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <h1>Способы оплаты</h1>
                    <?php if(!$payments->isEmpty()): ?>
                    <table>
                        <tr>
                            <th>Способы оплаты</th>
                            <th>Действия</th>
                        </tr>
                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($payment->payments); ?></td>
                                <td><a href="<?php echo e(route('payments.edit', $payment)); ?>" class="more"><i class="fa-regular
                                fa-pen-to-square"></i></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php else: ?>
                        <div class="btn-wrap" style="margin-top: 20px">
                            <a href="<?php echo e(route('payments.create')); ?>" class="more">Добавить</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/payments/index.blade.php ENDPATH**/ ?>