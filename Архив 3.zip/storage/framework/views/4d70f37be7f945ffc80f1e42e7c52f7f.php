<?php $__env->startSection('title', 'Поиск'); ?>

<?php $__env->startSection('content'); ?>

    <div class="pagetitle" style="background-image: url(<?php echo e(url('/')); ?>/img/page.jpg)">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 data-aos="fade-up" data-aos-duration="2000"><?php echo app('translator')->get('main.search'); ?></h1>
                    <ul class="breadcrumbs">
                        <li><a href="<?php echo e(route('homepage')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                        <li>></li>
                        <li><?php echo app('translator')->get('main.search'); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <?php if($hotel): ?>
    <div class="page hotel search">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <img src="<?php echo e(Storage::url($hotel->image)); ?>" alt="">
                </div>
                <div class="col-md-7">
                    <div class="description">
                        <h2><?php echo e($hotel->__('title')); ?></h2>
                        <div class="address"><?php echo e($hotel->__('address')); ?></div>
                        <div class="phone"><a href="tel:<?php echo e($hotel->__('phone')); ?>"><?php echo e($hotel->__('phone')); ?></a></div>
                        <div class="price"><?php echo app('translator')->get('main.from'); ?> <?php echo e($min); ?> <?php echo app('translator')->get('main.som'); ?></div>
                        <div class="btn-wrap">
                            <a href="<?php echo e(route('hotel', $hotel->code)); ?>" class="more">Показать все номера</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="change-form">
                <h2>Поменять даты</h2>
                <form class="row" action="<?php echo e(route('search')); ?>">
                    <input type="hidden" name="search" value="<?php echo e($hotel->__('title')); ?>">
                    <div class="col-md-4">
                        <input type="date" value="<?php echo e($start_d); ?>" name="start_d">
                    </div>
                    <div class="col-md-4">
                        <input type="date" value="<?php echo e($end_d); ?>" name="end_d">
                    </div>
                    <div class="col-md-4">
                        <button class="more"><?php echo app('translator')->get('main.search'); ?></button>
                    </div>
                </form>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="table-wrap">
                        <table>
                            <tr>
                                <th>Номер</th>
                                <th>Завтрак</th>
                                <th>Отмена</th>
                                <th>Стоимость</th>
                                <th>Оплата</th>
                                <th></th>
                            </tr>
                            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($room->__('title')); ?></td>
                                    <td>
                                        <?php if($room->hotel->breakfast != ''): ?>
                                            <?php echo app('translator')->get('main.breakfast'); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>0 <?php echo app('translator')->get('main.som'); ?></td>
                                    <td><?php echo e($room->price); ?> <?php echo app('translator')->get('main.som'); ?></td>
                                    <td><?php echo app('translator')->get('main.payment'); ?></td>
                                    <td><a href="<?php echo e(route('room', [isset($hotel) ? $hotel->code : $room->hotel->code, $room->code])); ?>" class="more"><?php echo app('translator')->get('main.more'); ?></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="location">
                <h2>Локация</h2>
                <div class="row">
                    <script src="https://maps.api.2gis.ru/2.0/loader.js"></script>
                    <div id="map" style="width: 100%; height: 300px;"></div>
                    <script>
                        DG.then(function () {
                            var map = DG.map('map', {
                                center: [<?php echo e($hotel->lat); ?>, <?php echo e($hotel->lng); ?>],
                                zoom: 14
                            });
                            DG.marker([<?php echo e($hotel->lat); ?>, <?php echo e($hotel->lng); ?>], {scrollWheelZoom: false})
                                .addTo(map)
                                .bindLabel('<?php echo e($hotel->__('title')); ?>', {
                                    static: true
                                });
                        });
                    </script>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
        <div class="page">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h3><?php echo app('translator')->get('main.not_hotel'); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/search.blade.php ENDPATH**/ ?>