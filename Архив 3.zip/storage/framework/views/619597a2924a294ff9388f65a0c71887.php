<?php $__env->startSection('title', 'Удобства и услуги'); ?>

<?php $__env->startSection('content'); ?>


    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <h1>Удобства и услуги</h1>
                    <?php if(!$services->isEmpty()): ?>
                    <table>
                        <tr>
                            <th>Услуги</th>
                            <th>Действия</th>
                        </tr>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($service->services); ?></td>
                                <td><a href="<?php echo e(route('services.edit', $service)); ?>" class="more"><i class="fa-regular fa-pen-to-square"></i></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>
                    <?php else: ?>
                        <div class="btn-wrap" style="margin-top: 20px">
                            <a href="<?php echo e(route('services.create')); ?>" class="more">Добавить</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', compact('hotel'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/services/index.blade.php ENDPATH**/ ?>