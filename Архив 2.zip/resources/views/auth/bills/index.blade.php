@extends('auth.layouts.master')

@section('title', 'Счета')

@section('content')

    <div class="page admin bills">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <h1>Соглашение</h1>
                </div>
                <div class="col-md-3">
                    <div class="btn-wrap">
                        <a href="{{ route('bills.create') }}" class="more add">Добавить</a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="sidebar">
                        <ul>
                            <li><a href="">Информация</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-9">
                    <table>
                        <tr>
                            <th>№</th>
                            <th>Дата заключения</th>
                            <th>Статус</th>
                            <th>Компания</th>
                            <th>Файлы</th>
                        </tr>
                        <tbody>
                        @foreach($bills as $bill)
                            <tr>
                                <td>{{ $bill->id }}</td>
                                <td>{{ $bill->date }}</td>
                                <td>
                                    @if($bill->status==1)
                                        <div class="status"><i class="fa-regular fa-check"></i> Активный</div>
                                    @else

                                    @endif
                                </td>
                                <td>{{ $bill->title }}</td>
                                <td><a href="">Файлы</a></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

@endsection
