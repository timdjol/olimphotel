@extends('auth.layouts.master')

@isset($status)
    @section('title', 'Редактировать страницу' . $status->title)
@else
    @section('title', 'Создать страницу')
@endisset

@section('content')

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    @include('auth.layouts.sidebar')
                </div>
                <div class="col-md-9">
                    <form method="post" action="{{ route('services.update', $service) }}">
                        @method('PUT')
                        <input type="hidden" name="title" value="Услуги">
                        <input type="hidden" name="hotel_id" value="{{ $hotel->id }}">
                        <div class="row">
                            <div class="name">Услуги</div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input type="checkbox" name="services[]" id="rent" value="Аренда авто" {{
                                    in_array('Аренда авто', $services) ? 'checked' : '' }}>
                                    <label for="rent">Аренда авто</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="zal" type="checkbox" name="services[]" value="Спорт зал" {{
                                    in_array('Спорт зал', $services) ? 'checked' : '' }}>
                                    <label for="zal">Спорт зал</label>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="conf" type="checkbox" name="services[]" value="Аренда конференц-зала" {{
                                    in_array('Аренда конференц-зала', $services) ? 'checked' : '' }}>
                                    <label for="conf">Аренда конференц-зала</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="pool" type="checkbox" name="services[]" value="Бассейн" {{
                                    in_array('Бассейн', $services) ? 'checked' : '' }}>
                                    <label for="pool">Бассейн</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="air" type="checkbox" name="services[]" value="Встреча в аэропорту" {{
                                    in_array('Встреча в аэропорту', $services) ? 'checked' : '' }}>
                                    <label for="air">Встреча в аэропорту</label>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="gid" type="checkbox" name="services[]" value="Гид" {{
                                    in_array('Гид', $services) ? 'checked' : '' }}>
                                    <label for="gid">Гид</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="mas" type="checkbox" name="services[]" value="Массаж" {{
                                    in_array('Массаж', $services) ? 'checked' : '' }}>
                                    <label for="mas">Массаж</label>
                                </div>
                            </div>
                        </div>
                        @csrf
                        <button class="more">Отправить</button>
                        <a href="{{url()->previous()}}" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <style>
        .admin label {
            display: inline-block;
        }
    </style>

@endsection
