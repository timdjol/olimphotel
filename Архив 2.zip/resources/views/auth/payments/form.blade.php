@extends('auth.layouts.master')

@isset($status)
    @section('title', 'Редактировать страницу')
@else
    @section('title', 'Создать страницу')
@endisset

@section('content')

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    @include('auth.layouts.sidebar')
                </div>
                <div class="col-md-9">
                    <h1>Способы оплаты</h1>
                    <form method="post" action="{{ route('payments.update', $payment) }}">
                        @method('PUT')
                        <input type="hidden" name="hotel_id" value="{{ $hotel->id }}">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input type="checkbox" name="payments[]" id="visa" value="VISA" {{
                                    in_array('VISA', $payments) ? 'checked' : '' }}>
                                    <label for="visa">VISA</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="zal" type="checkbox" name="payments[]" value="MasterCard" {{
                                    in_array('MasterCard', $payments) ? 'checked' : '' }}>
                                    <label for="zal">MasterCard</label>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="conf" type="checkbox" name="payments[]" value="Elcat" {{
                                    in_array('Elcat', $payments) ? 'checked' : '' }}>
                                    <label for="conf">Elcat</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="pool" type="checkbox" name="payments[]" value="PayPal" {{
                                    in_array('PayPal', $payments) ? 'checked' : '' }}>
                                    <label for="pool">PayPal</label>
                                </div>
                            </div>
                        </div>
                        @csrf
                        <button class="more">Отправить</button>
                        <a href="{{url()->previous()}}" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <style>
        .admin label {
            display: inline-block;
        }
    </style>

@endsection
