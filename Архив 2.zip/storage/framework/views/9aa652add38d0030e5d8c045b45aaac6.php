<?php $__env->startSection('title', 'Категория ' . $travel->title); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <h1>Экскурсия <?php echo e($travel->title); ?></h1>
                    <table class="table">
                        <tr>
                            <td>ID</td>
                            <td><?php echo e($travel->id); ?></td>
                        </tr>
                        <tr>
                            <td>Код</td>
                            <td><?php echo e($travel->code); ?></td>
                        </tr>
                        <tr>
                            <td>Название</td>
                            <td><?php echo e($travel->title); ?></td>
                        </tr>
                        <tr>
                            <td>Название EN</td>
                            <td><?php echo e($travel->title_en); ?></td>
                        </tr>
                        <tr>
                            <td>Описание</td>
                            <td><?php echo $travel->description; ?></td>
                        </tr>
                        <tr>
                            <td>Описание EN</td>
                            <td><?php echo $travel->description_en; ?></td>
                        </tr>
                        <tr>
                            <td>Изображение</td>
                            <td><img src="<?php echo e(Storage::url($travel->image)); ?>"></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/orders/show.blade.php ENDPATH**/ ?>