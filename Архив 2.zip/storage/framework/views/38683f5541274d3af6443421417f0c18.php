<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <!-- <base href="/"> -->

    <title><?php echo $__env->yieldContent('title'); ?> - StayBook</title>
    <meta name="description" content="">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Template Basic Images Start -->
    <meta property="og:image" content="path/to/image.jpg">
    <link rel="icon" href="<?php echo e(route('index')); ?>/img/favicon/favicon.ico">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(route('index')); ?>/img/favicon/apple-touch-icon-180x180.png">
    <!-- Template Basic Images End -->

    <!-- Custom Browser Color Start -->
    <meta name="theme-color" content="#000">
    <!-- Custom Browsers Color End -->

    <link href="https://cdn.jsdelivr.net/gh/eliyantosarage/font-awesome-pro@main/fontawesome-pro-6.5.1-web/css/all.min.css"
          rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(route('index')); ?>/css/admin.css">
    <link rel="stylesheet" href="<?php echo e(route('index')); ?>/css/main.min.css">

</head>

<body>
<header>
    <div class="container">
        <div class="row">
            <div class="col-md-2">
                <div class="logo">
                    <a href="<?php echo e(route('hotels.index')); ?>"><img src="https://silkway.timmedia.store/img/logo.png" alt=""></a>
                </div>
            </div>
            <div class="col-md-4">
                <form>
                    <select id="dynamic_select">
                        <option><?php echo app('translator')->get('main.choose'); ?></option>
                        <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(route('hotels.show', $hotel)); ?>"><?php echo e($hotel->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>
            </div>
            <div class="col-md-3">
                <div class="status active"><i class="fa-solid fa-circle"></i> Active</div>
            </div>
            <div class="col-md-3">
                <div class="homelink">
                    <a href="<?php echo e(route('index')); ?>"><i class="fas fa-house"></i> Перейти на сайт</a></a>
                </div>
            </div>
        </div>
    </div>
    <div class="head">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <nav>
                        <ul>
                            <li <?php echo Route::currentRouteNamed('hotels.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('hotels.index')); ?>"><i class="fas
                            fa-hotel"></i> Отели</a></li>
                            <li <?php echo Route::currentRouteNamed('bookings.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('bookings.index')); ?>"><i
                                        class="fa-regular
                            fa-tag"></i> Цены и наличие</a></li>
                            <li <?php echo Route::currentRouteNamed('listbooks.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('listbooks.index')); ?>"><i
                                        class="fa-regular fa-tag"></i> Брони</a></li>
                            <li <?php echo Route::currentRouteNamed('rooms.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('rooms.index')); ?>"><i class="fas
                            fa-booth-curtain"></i> Номера и цены</a></li>
                            <li><a href="<?php echo e(route('bills.index')); ?>"><i class="fa-thin fa-money-bills"></i> Счета</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-md-4 person">
                    <a href="<?php echo e(route('profile.edit')); ?>"><i class="fa-regular fa-address-card"></i> Профиль</a>
                    <a href="<?php echo e(route('logout')); ?>" class="delete"><i class="fa-regular fa-door-open"></i> Выйти</a>
                </div>
            </div>
        </div>
    </div>
</header>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(session()->has('success')): ?>
                <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
            <?php endif; ?>
            <?php if(session()->has('warning')): ?>
                <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php echo $__env->yieldContent('content'); ?>













<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script>
    $(function() {
        $('#dynamic_select').on('change', function() {
            var url = $(this).val(); // get selected value
            if (url) { // require a URL
                window.location = url; // redirect
            }
            return false;
        });
    });
</script>

</body>
</html>

<?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/layouts/master.blade.php ENDPATH**/ ?>