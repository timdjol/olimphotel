<?php $__env->startSection('title', 'Отели'); ?>

<?php $__env->startSection('content'); ?>

    <div class="pagetitle" style="background-image: url(<?php echo e(url('/')); ?>/img/page.jpg)">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 data-aos="fade-up" data-aos-duration="2000"><?php echo app('translator')->get('main.hotels'); ?></h1>
                    <ul class="breadcrumbs">
                        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                        <li>></li>
                        <li><?php echo app('translator')->get('main.hotels'); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="page hotels">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-6" data-aos="zoom-in" data-aos-duration="2000">
                        <div class="hotels-item" style="background-image: url(<?php echo e(Storage::url($hotel->image)); ?>)">
                            <a href="<?php echo e(route('hotel', $hotel->code)); ?>">
                                <div class="overlay"></div>
                                <div class="text-wrap">
                                    <h4><?php echo e($hotel->__('title')); ?></h4>
                                    <div class="address"><?php echo e($hotel->__('address')); ?></div>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/pages/hotels.blade.php ENDPATH**/ ?>