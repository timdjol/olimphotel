<?php $__env->startSection('title', 'Главная страница'); ?>

<?php $__env->startSection('content'); ?>

    <div class="owl-carousel owl-slider">
        <div class="slider-item">
            <div class="slider-item" style="background-image: url(https://silkway.timmedia.store/storage/app/public/sliders/zcST2Jgo1uaK3e3CkF1Kbmq8gu4E1TD7HpvL4Mza.jpg)"></div>
        </div>
        <div class="slider-item">
            <div class="slider-item" style="background-image: url(https://silkway.timmedia.store/storage/app/public/sliders/PNdFu2gwhQIbrteQ5tpzwGjLJiakmMfnyBE3Zw5E.jpg)"></div>
        </div>
        <div class="slider-item">
            <div class="slider-item" style="background-image: url(https://silkway.timmedia.store/storage/app/public/sliders/Kim5wvZ8yQoPQUx5f6LjCgyQsMZAPewkr7eJULRF.jpg)"></div>
        </div>
    </div>
    <div class="search homesearch">
        <div class="container">
            <form action="<?php echo e(route('search')); ?>" class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="">Поиск по названию отеля</label>
                        <input type="search" name="search" required>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="">Дата заезда</label>
                        <input type="date" id="start_d" name="start_d">
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="">Дата выезда</label>
                        <input type="date" id="end_d" name="end_d">
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="">Кол-во гостей</label>
                        <select name="count" id="">
                            <option>Выбрать</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group check">
                        <input type="checkbox" name="checkin" id="check">
                        <label for="check">Ранний заезд</label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <button class="more">Поиск</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="rooms home-rooms">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 data-aos="fade-up" data-aos-duration="2000"><?php echo app('translator')->get('main.rooms'); ?></h2>
                </div>
            </div>
            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('layouts.card', compact('room'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="paginate">
                    <?php echo e($rooms->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>

    <style>
        .check{
            margin-top: 40px;
        }
        input[type="checkbox"]{
            width: auto;
            height: auto;
            display: inline-block;
        }

    </style>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/pages/home.blade.php ENDPATH**/ ?>