<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <h1>Бронь на имя <?php echo e($book->title); ?></h1>
                    <table class="table">
                        <tr>
                            <th>Номер брони</th>
                            <td><?php echo e($book->id); ?></td>
                        </tr>
                        <tr>
                            <th>Отель</th>
                            <td><?php echo e($hotel->title); ?></td>
                        </tr>
                        <tr>
                            <th>Номер</th>
                            <td><?php echo e($room->title); ?></td>
                        </tr>
                        <tr>
                            <th>Номер телефона</th>
                            <td><a href="tel:<?php echo e($book->phone); ?>"><?php echo e($book->phone); ?></a></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><a href="mailto:<?php echo e($book->email); ?>"><?php echo e($book->email); ?></a></td>
                        </tr>
                        <tr>
                            <th>Количество Взрослых</th>
                            <td><?php echo e($book->count); ?></td>
                        </tr>
                        <tr>
                            <th>Количество Детей</th>
                            <td><?php echo e($book->countc); ?></td>
                        </tr>
                        <tr>
                            <th>Стоимость</th>
                            <td><?php echo e($book->sum); ?></td>
                        </tr>
                        <tr>
                            <th>Дата заезда</th>
                            <td><?php echo e($book->start_d); ?></td>
                        </tr>
                        <tr>
                            <th>Дата выезда</th>
                            <td><?php echo e($book->end_d); ?></td>
                        </tr>
                        <tr>
                            <th>Комментарий</th>
                            <td><?php echo e($book->comment); ?></td>
                        </tr>
                        <tr>
                            <th>Статус</th>
                            <td>
                                <?php if($book->status == 'Забронирован'): ?>
                                    <div class="more success"><?php echo e($book->status); ?></div>
                                <?php endif; ?>
                            </td>
                        </tr>


                    </table>
                </div>
            </div>
        </div>
    </div>

    <style>
        .success{
            padding: 5px 20px;
            background-color: green;
            color: #fff;
            display: inline-block;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/manager/books/show.blade.php ENDPATH**/ ?>