
    <div class="row rooms-item">
        <div class="col-lg-4 col-md-6" data-aos="fade-right" data-aos-duration="2000">
            <a href="<?php echo e(route('room', [isset($hotel) ? $hotel->code : $room->hotel->code, $room->code])); ?>">
                <div class="img" style="background-image: url(<?php echo e(Storage::url($room->image)); ?>)"></div>
            </a>
        </div>
        <div class="col-lg-6 col-md-6">
            <div class="start"><?php echo app('translator')->get('main.start_d'); ?> <?php echo e($room->hotel->checkin); ?></div>
            <div class="end"><?php echo app('translator')->get('main.end_d'); ?> <?php echo e($room->hotel->checkout); ?></div>
            <div class="title"><?php echo e($room->hotel->__('title')); ?></div>
            <h3><?php echo e($room->__('title')); ?></h3>
            <div class="address"><?php echo e($room->hotel->__('address')); ?></div>
            <div class="d-xl-none d-lg-none d-block">
                <div class="price"><?php echo e($room->price); ?> <?php echo app('translator')->get('main.som'); ?></div>
                <?php if($room->hotel->breakfast != ''): ?>
                    <div class="breakfast"><?php echo app('translator')->get('main.breakfast'); ?></div>
                <?php endif; ?>
            </div>
            <div class="btn-wrap">
                <a href="<?php echo e(route('room', [isset($hotel) ? $hotel->code : $room->hotel->code, $room->code])); ?>" class="more"><?php echo app('translator')->get('main.more'); ?></a>
            </div>
        </div>
        <div class="col-lg-2 d-xl-block d-lg-block d-none" data-aos="fade-left" data-aos-duration="2000">
            <div class="price"><?php echo e($room->price); ?> <?php echo app('translator')->get('main.som'); ?></div>
            <?php if($room->hotel->breakfast != ''): ?>
                <div class="breakfast"><?php echo app('translator')->get('main.breakfast'); ?></div>
            <?php endif; ?>
        </div>
    </div>
<?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/layouts/card.blade.php ENDPATH**/ ?>