<?php if(isset($status)): ?>
    <?php $__env->startSection('title', 'Редактировать страницу' . $status->title); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Создать страницу'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <form method="post" action="<?php echo e(route('services.update', $service)); ?>">
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="title" value="Услуги">
                        <input type="hidden" name="hotel_id" value="<?php echo e($hotel->id); ?>">
                        <div class="row">
                            <div class="name">Услуги</div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input type="checkbox" name="services[]" id="rent" value="Аренда авто" <?php echo e(in_array('Аренда авто', $services) ? 'checked' : ''); ?>>
                                    <label for="rent">Аренда авто</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="zal" type="checkbox" name="services[]" value="Спорт зал" <?php echo e(in_array('Спорт зал', $services) ? 'checked' : ''); ?>>
                                    <label for="zal">Спорт зал</label>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="conf" type="checkbox" name="services[]" value="Аренда конференц-зала" <?php echo e(in_array('Аренда конференц-зала', $services) ? 'checked' : ''); ?>>
                                    <label for="conf">Аренда конференц-зала</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="pool" type="checkbox" name="services[]" value="Бассейн" <?php echo e(in_array('Бассейн', $services) ? 'checked' : ''); ?>>
                                    <label for="pool">Бассейн</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="air" type="checkbox" name="services[]" value="Встреча в аэропорту" <?php echo e(in_array('Встреча в аэропорту', $services) ? 'checked' : ''); ?>>
                                    <label for="air">Встреча в аэропорту</label>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="gid" type="checkbox" name="services[]" value="Гид" <?php echo e(in_array('Гид', $services) ? 'checked' : ''); ?>>
                                    <label for="gid">Гид</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="mas" type="checkbox" name="services[]" value="Массаж" <?php echo e(in_array('Массаж', $services) ? 'checked' : ''); ?>>
                                    <label for="mas">Массаж</label>
                                </div>
                            </div>
                        </div>
                        <?php echo csrf_field(); ?>
                        <button class="more">Отправить</button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <style>
        .admin label {
            display: inline-block;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/services/form.blade.php ENDPATH**/ ?>