<?php $__env->startSection('title', 'Счета'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin bills">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <h1>Соглашение</h1>
                </div>
                <div class="col-md-3">
                    <div class="btn-wrap">
                        <a href="<?php echo e(route('bills.create')); ?>" class="more add">Добавить</a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="sidebar">
                        <ul>
                            <li><a href="">Информация</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-9">
                    <table>
                        <tr>
                            <th>№</th>
                            <th>Дата заключения</th>
                            <th>Статус</th>
                            <th>Компания</th>
                            <th>Файлы</th>
                        </tr>
                        <tbody>
                        <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($bill->id); ?></td>
                                <td><?php echo e($bill->date); ?></td>
                                <td>
                                    <?php if($bill->status==1): ?>
                                        <div class="status"><i class="fa-regular fa-check"></i> Активный</div>
                                    <?php else: ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($bill->title); ?></td>
                                <td><a href="">Файлы</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/bills/index.blade.php ENDPATH**/ ?>