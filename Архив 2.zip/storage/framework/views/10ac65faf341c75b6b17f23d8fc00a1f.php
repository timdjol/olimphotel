<?php if(isset($status)): ?>
    <?php $__env->startSection('title', 'Редактировать страницу'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Создать страницу'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <h1>Способы оплаты</h1>
                    <form method="post" action="<?php echo e(route('payments.update', $payment)); ?>">
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="hotel_id" value="<?php echo e($hotel->id); ?>">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input type="checkbox" name="payments[]" id="visa" value="VISA" <?php echo e(in_array('VISA', $payments) ? 'checked' : ''); ?>>
                                    <label for="visa">VISA</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="zal" type="checkbox" name="payments[]" value="MasterCard" <?php echo e(in_array('MasterCard', $payments) ? 'checked' : ''); ?>>
                                    <label for="zal">MasterCard</label>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="conf" type="checkbox" name="payments[]" value="Elcat" <?php echo e(in_array('Elcat', $payments) ? 'checked' : ''); ?>>
                                    <label for="conf">Elcat</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="pool" type="checkbox" name="payments[]" value="PayPal" <?php echo e(in_array('PayPal', $payments) ? 'checked' : ''); ?>>
                                    <label for="pool">PayPal</label>
                                </div>
                            </div>
                        </div>
                        <?php echo csrf_field(); ?>
                        <button class="more">Отправить</button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <style>
        .admin label {
            display: inline-block;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/payments/form.blade.php ENDPATH**/ ?>