<?php $__env->startSection('title', 'Заявки с экскурсий'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(session()->has('success')): ?>
                        <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
                    <?php endif; ?>
                    <?php if(session()->has('warning')): ?>
                        <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-md-12">
                            <h1>Заявки с экскурсий</h1>
                        </div>
                    </div>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Экскурсия</th>
                            <th>Тип</th>
                            <th>Дата</th>
                            <th>Кол-во</th>
                            <th>Имя</th>
                            <th>Телефон</th>
                            <th>Email</th>
                            <th>Действия</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($order->travel); ?></td>
                                <td><?php echo e($order->choose); ?></td>
                                <td><?php echo e($order->dates); ?></td>
                                <td><?php echo e($order->count); ?></td>
                                <td><?php echo e($order->name); ?></td>
                                <td><a href="tel:<?php echo e($order->phone); ?>"><?php echo e($order->phone); ?></a></td>
                                <td><a href="mailto:<?php echo e($order->email); ?>"><?php echo e($order->email); ?></a></td>
                                <td>
                                    <form action="<?php echo e(route('orders.destroy', $order)); ?>" method="post">
                                        <ul>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn delete">Удалить</button>
                                        </ul>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($orders->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>

    <style>
        table th, table td{
            font-size: 14px;
            line-height: 1.2;
            padding: 5px;
        }
        .admin table ul{
            padding-left: 0;
        }
        table a{
            color: #009291;
            text-decoration: none;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/orders/index.blade.php ENDPATH**/ ?>