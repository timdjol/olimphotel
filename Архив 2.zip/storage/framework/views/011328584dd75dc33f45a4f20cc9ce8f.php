<?php if(isset($policy)): ?>
    <?php $__env->startSection('title', 'Редактировать страницу'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Создать страницу'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <h1>Способы оплаты</h1>
                    <form method="post" action="<?php echo e(route('policies.update', $policy)); ?>">
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="hotel_id" value="<?php echo e($hotel->id); ?>">
                        <div class="form-group">
                            <label for="">Ранний въезд</label>
                            <select name="checkin" id="">
                                <option value="02:00">02:00</option>
                                <option value="03:00">03:00</option>
                                <option value="04:00">04:00</option>
                                <option value="05:00">05:00</option>
                                <option value="06:00">06:00</option>
                                <option value="07:00">07:00</option>
                                <option value="08:00">08:00</option>
                                <option value="09:00">09:00</option>
                                <option value="10:00">10:00</option>
                                <option value="11:00">11:00</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Поздний выезд</label>
                            <select name="checkout" id="">
                                <option value="15:00">15:00</option>
                                <option value="16:00">16:00</option>
                                <option value="17:00">17:00</option>
                                <option value="18:00">18:00</option>
                                <option value="19:00">19:00</option>
                                <option value="20:00">20:00</option>
                                <option value="21:00">21:00</option>
                                <option value="22:00">22:00</option>
                                <option value="23:00">23:00</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Дополнительное место</label>
                            <input type="number" name="extra" value="<?php echo e($policy->extra); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Наценка</label>
                            <input type="number" name="amount" value="<?php echo e($policy->amount); ?>">
                        </div>
                        <?php echo csrf_field(); ?>
                        <button class="more">Отправить</button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <style>
        .admin label {
            display: inline-block;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/policies/form.blade.php ENDPATH**/ ?>