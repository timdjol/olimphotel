<?php if(isset($book)): ?>
    <?php $__env->startSection('title', 'Редактировать бронирование ' . $book->title); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Добавить бронирование'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(isset($book)): ?>
                        <h1>Редактировать бронирование <?php echo e($book->title); ?></h1>
                    <?php else: ?>
                        <h1>Добавить бронирование</h1>
                    <?php endif; ?>
                    <form method="post"
                          <?php if(isset($book)): ?>
                              action="<?php echo e(route('hotel.books.update', $book)); ?>"
                          <?php else: ?>
                              action="<?php echo e(route('hotel.books.store')); ?>"
                            <?php endif; ?>
                    >
                        <?php if(isset($book)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <div class="form-group">
                            <label for="">Отель</label>
                            <select name="hotels" id="hotels">
                                <option>Все отели</option>
                                <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($hotel->id); ?>" <?php if(old('hotels') == $hotel->id): echo 'selected'; endif; ?>
                                    ><?php echo e($hotel->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Выберите комнату</label>
                            <select name="rooms" id="rooms">
                            </select>
                        </div>



                        <input type="hidden" name="status" id="status" value="Забронирован">
                        <div class="form-group">
                            <label class="col-xs-4" for="title">Ваше имя</label>
                            <input type="text" class="form-control" name="title" id="title" required/>
                            <span id="titleError" class="text-danger"></span>
                        </div>

                        <div class="form-group">
                            <label class="col-xs-4" for="phone">Номер телефона</label>
                            <input type="number" class="form-control" name="phone" id="phone" required>
                            <div id="output" class="output"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-4" for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email"/>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-4" for="content">Комментарий</label>
                            <input type="text" class="form-control" name="comment" id="comment"/>
                        </div>

                        <div class="form-group">
                            <label class="col-xs-4" for="count">Кол-во взрослых</label>
                            <select name="count" id="count" required>
                                <option value="0">Выбрать</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="col-xs-4" for="countс">Кол-во детей</label>
                            <select name="countc" id="countc" required>
                                <option value="0">Выбрать</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="">Стоимость</label>
                            <input type="text" id="sum" name="sum" readonly>
                        </div>

                        <div class="form-group">
                            <label class="col-xs-4" for="start_d">Дата заезда:</label>
                            <input type="text" name="start_d" readonly id="start_d"/>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-4" for="end_d">Дата выезда</label>
                            <input type="text" name="end_d" readonly id="end_d"/>
                        </div>
                        <?php echo csrf_field(); ?>
                        <button class="more">Отправить</button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script>
    $(document).ready(function () {
        $('#hotels').on('change', function () {
            let idHotel = this.value;
            $("#rooms").html('');
            $.ajax({
                url: "<?php echo e(url('api/fetch-rooms')); ?>",
                type: "POST",
                data: {
                    hotel_id: idHotel,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                dataType: 'json',
                success: function (result) {
                    $('#rooms').html('<option value="">Выбрать</option>');
                    $.each(result.rooms, function (key, value) {
                        $("#rooms").append('<option value="' + value
                            .id + '" data-price="' + value.price + '" data-pricec="' + value.pricec + '" ' +
                            'data-count="' + value.count + '">' + value
                            .title + '</option>');
                    });
                    //$("#rooms").append('<div class="price">' + value.price + '"</div>"');
                }
            });
        });

        $("#count, #countc").change(function(){
            let price = $('#price').text();
            let pricec = $('#pricec').text();
            let count = $('#count').val();
            //let countc = $('#countc').val();
            let start_d = $.fullCalendar.formatDate(start, "Y-MM-DD");
            let end_d = $.fullCalendar.formatDate(end, "Y-MM-DD");
            let st = new Date(start_d);
            let en = new Date(end_d);
            let millisecondsPerDay = 1000 * 60 * 60 * 24;
            let millisBetween = en.getTime() - st.getTime();
            let days = millisBetween / millisecondsPerDay;
            let sum = (price * count * days) + (pricec * countc * days);
            $('#sum').val(sum + ' сом');
        });

    });
</script>
<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/hotel/books/form.blade.php ENDPATH**/ ?>