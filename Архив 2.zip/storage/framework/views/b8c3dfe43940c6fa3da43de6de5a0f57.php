<?php $__env->startSection('title', $hotel->__('title')); ?>

<?php $__env->startSection('content'); ?>

    <div class="page hotel">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-12">
                    <img src="<?php echo e(Storage::url($hotel->image)); ?>" alt="">
                </div>
                <div class="col-lg-7 col-md-12">
                    <h1><?php echo e($hotel->__('title')); ?></h1>
                    <?php echo $hotel->__('description'); ?>

                    <div class="phone"><span><?php echo app('translator')->get('main.hphone'); ?></span> <a href="tel:<?php echo e($hotel->phone); ?>"><?php echo e($hotel->phone); ?></a></div>
                    <div class="address"><span><?php echo app('translator')->get('main.address'); ?></span> <?php echo e($hotel->address); ?></div>
                    <div class="email"><span>Email:</span> <a href="mailto:<?php echo e($hotel->email); ?>"><?php echo e($hotel->email); ?></a>
                    </div>
                </div>
            </div>
            <div class="row">
                <script src="https://maps.api.2gis.ru/2.0/loader.js"></script>
                <div id="map" style="width: 100%; height: 300px;"></div>
                <script>
                    DG.then(function () {
                        var map = DG.map('map', {
                            center: [<?php echo e($hotel->lat); ?>, <?php echo e($hotel->lng); ?>],
                            zoom: 14
                        });

                        DG.marker([<?php echo e($hotel->lat); ?>, <?php echo e($hotel->lng); ?>], {scrollWheelZoom: false})
                            .addTo(map)
                            .bindLabel('<?php echo e($hotel->__('title')); ?>', {
                                static: true
                            });
                    });
                </script>
            </div>
        </div>
    </div>

    <div class="rooms">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="showed"><?php echo app('translator')->get('main.showed'); ?> <?php echo e($rooms->count()); ?></div>
                </div>
            </div>
            <?php if($rooms->isNotEmpty()): ?>
                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('layouts.card', compact('room'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="alert alert-danger"><?php echo app('translator')->get('main.not_found'); ?></div>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="pagination">
                        <?php echo e($rooms->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/pages/hotel.blade.php ENDPATH**/ ?>