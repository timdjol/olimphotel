<?php $__env->startSection('title', 'Номера'); ?>

<?php $__env->startSection('content'); ?>

    <div class="pagetitle" style="background-image: url(<?php echo e(url('/')); ?>/img/page.jpg)">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 data-aos="fade-up" data-aos-duration="2000"><?php echo app('translator')->get('main.rooms'); ?></h1>
                    <ul class="breadcrumbs">
                        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                        <li>></li>
                        <li><?php echo app('translator')->get('main.rooms'); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="page rooms">
        <div class="container">
            <div class="row">
                <div class="col-md-3 d-xl-block d-lg-block d-none">
                    <div class="filter">
                        <h4><?php echo app('translator')->get('main.filter'); ?></h4>
                        <form class="row">
                            <div class="form-group">
                                <label for="hotel"><?php echo app('translator')->get('main.hotel'); ?></label>
                                <select id="hotel">
                                    <option value="0"><?php echo app('translator')->get('main.choose'); ?></option>
                                    <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($hotel->id); ?>" <?php echo e(old('hotel') == $hotel->id ? 'selected' : ''); ?>><?php echo e($hotel->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="amount"><?php echo app('translator')->get('main.amount_from'); ?></label>
                                <input type="text" id="amount" readonly>
                                <div id="slider-range"></div>
                                <input type="hidden" id="min">
                                <input type="hidden" id="max">
                            </div>
                            <div class="form-group">
                                <label for="count"><?php echo app('translator')->get('main.count'); ?></label>
                                <select id="count">
                                    <option value="0"><?php echo app('translator')->get('main.choose'); ?></option>
                                    <?php for($i=1; $i < $max_per; $i++): ?>
                                        <option value="<?php echo e($i); ?>"> <?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="date"><?php echo app('translator')->get('main.date_from'); ?></label>
                                <input type="text" id="from" name="from">
                            </div>
                            <div class="form-group">
                                <label for="date"><?php echo app('translator')->get('main.date_to'); ?></label>
                                <input type="text" id="to" name="to">
                            </div>
                            <div class="form-group">
                                <button class="more" type="button" id="filter_btn"><?php echo app('translator')->get('main.apply'); ?></button>
                                <a href="<?php echo e(route('allrooms')); ?>" class="delete"><?php echo app('translator')->get('main.reset'); ?></a>
                            </div>
                        </form>

                        <script src="https://maps.api.2gis.ru/2.0/loader.js"></script>
                        <div id="map" style="width: 100%; height: 300px;"></div>
                        <script>
                            DG.then(function () {
                                var map = DG.map('map', {
                                    center: [42.855608, 74.618626],
                                    zoom: 12
                                });

                                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                DG.marker([<?php echo e($room->hotel->lat); ?>, <?php echo e($room->hotel->lng); ?>], {
                                    scrollWheelZoom:
                                        false
                                })
                                    .addTo(map)
                                    .bindLabel('<a target="_blank" href="<?php echo e(route('hotel', $room->hotel->code)); ?>"><?php echo e(Illuminate\Support\Str::limit
                                        (strip_tags($room->hotel->__('title')),12)); ?><br><?php echo e($room->where('hotel_id',
                                        $room->hotel->id)->whereNotNull('price')->min("price")); ?> <?php echo app('translator')->get('main.som'); ?>
                                        </a>', {
                                        static: true
                                    });
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            });
                        </script>

                    </div>
                </div>
                <div class="col-md-9">
                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('layouts.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <?php echo e($rooms->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>


        </div>
    </div>

    <script>
        $("#slider-range").slider({
            range: true,
            min: <?php echo e($min); ?>,
            max: <?php echo e($max); ?>,
            values: [<?php echo e($min); ?>, <?php echo e($max); ?>],
            slide: function (event, ui) {
                $("#amount").val(ui.values[0] + " - " + ui.values[1]);
                $('#min').val(ui.values[0]);
                $('#max').val(ui.values[1]);
            }
        });
        $("#amount").val($("#slider-range").slider("values", 0) +
            " - " + $("#slider-range").slider("values", 1));


        function submit_post_filter() {
            let appUrl = <?php echo json_encode(url('/')); ?>;
            let hotel = $('#hotel').val();
            let price_from = $('#min').val();
            let price_to = $('#max').val();
            let count = $('#count').val();
            let date_from = $('#from').val();
            let date_to = $('#to').val();

            if (price_from != '') {
                price_from = price_from;
            } else {
                price_from = '0';
            }

            if (price_to != '') {
                price_to = price_to;
            } else {
                price_to = '100000';
            }

            if (date_from != '') {
                date_from = date_from;
            } else {
                date_from = '';
            }

            if (date_to != '') {
                date_to = date_to;
            } else {
                date_to = '';
            }

            window.location.href = appUrl + '/allrooms/' + hotel + '/' + price_from + '/' + price_to + '/' + count +
                '/' + date_from + '/' + date_to;
        }

        $(document).ready(function () {
            $('#filter_btn').click(function () {
                submit_post_filter();
            });

        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/pages/rooms.blade.php ENDPATH**/ ?>