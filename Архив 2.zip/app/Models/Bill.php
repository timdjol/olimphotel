<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Bill extends Model
{

    protected $fillable = [
        'title',
        //'files',
        'status',
        'date',
    ];
}
