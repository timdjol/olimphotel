<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Hotel;
use App\Models\Policy;
use Illuminate\Http\Request;

class PolicyController extends Controller
{
    public function index()
    {
        $hotel = Hotel::firstOrFail();
        $policies = Policy::where('hotel_id', $hotel->id)->get();
        return view('auth.policies.index', compact('policies', 'hotel'));
    }

    public function edit(Policy $policy)
    {
        $hotel = Hotel::firstOrFail();
        return view('auth.policies.form', compact('policy', 'hotel'));
    }

    public function update(Request $request, Policy $policy)
    {
        $params = $request->all();
        $policy->update($params);
        session()->flash('success', 'Политика обновлена');

        return redirect()->route('policies.index');
    }

}
