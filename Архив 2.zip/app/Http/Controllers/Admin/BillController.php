<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\HotelRequest;
use App\Models\Bill;
use App\Models\Hotel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class BillController extends Controller
{
    public function index()
    {
        $bills = Bill::all();
        return view('auth.bills.index', compact('bills'));
    }

    public function create()
    {
        return view('auth.bills.form');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $params = $request->all();
        Bill::create($params);

        session()->flash('success', 'Соглашение ' . $request->title . ' добавлено');
        return redirect()->route('bills.index');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Bill $bill)
    {
        return view('auth.bills.form', compact('bill'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Bill $bill)
    {
        $params = $request->all();
        $bill->update($params);

        session()->flash('success', 'Соглашение ' . $request->title . ' обновлено');
        return redirect()->route('bills.index');
    }
}
