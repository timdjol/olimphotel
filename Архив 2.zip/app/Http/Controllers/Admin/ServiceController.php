<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Hotel;
use App\Models\Service;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
    public function index()
    {
        $hotel = Hotel::firstOrFail();
        $services = Service::where('hotel_id', $hotel->id)->get();
        return view('auth.services.index', compact('services', 'hotel'));
    }

    public function edit(Service $service)
    {
        $hotel = Hotel::firstOrFail();
        $services = explode(', ', $service->services);
        return view('auth.services.form', compact('service', 'hotel', 'services'));
    }

    public function update(Request $request, Service $service)
    {
        $params = [
            'title' => $request->title,
            'hotel_id' => $request->hotel_id,
            'services' => implode(', ', $request->services),
        ];
        //$params = $request->all();
        $service->update($params);
        session()->flash('success', 'Услуги обновлены');

        return redirect()->route('services.index');
    }

}
