<?php

namespace App\ViewComposers;

use App\Models\Hotel;
use Illuminate\View\View;

class HotelsComposer
{
    public function compose(View $view){
        $hotels = Hotel::get();
        $view->with('hotels', $hotels);
    }
}