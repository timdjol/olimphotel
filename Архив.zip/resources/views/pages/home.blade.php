@extends('layouts.master')

@section('title', 'Главная страница')

@section('content')

    <div class="slider">
        <div class="owl-carousel owl-slider">
            @foreach($sliders as $slider)
                <div class="slider-item">
                    <div class="slider-item" style="background-image: url({{ Storage::url($slider->image) }})"></div>
                </div>
            @endforeach
        </div>
    </div>

    <div class="rooms home-rooms">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 data-aos="fade-up" data-aos-duration="2000">@lang('main.rooms')</h2>
                </div>
            </div>
            @foreach($rooms as $room)
                @include('layouts.card', compact('room'))
            @endforeach
            <div class="row">
                <div class="paginate">
                    {{ $rooms->links('pagination::bootstrap-4') }}
                </div>
            </div>
        </div>
    </div>


@endsection
