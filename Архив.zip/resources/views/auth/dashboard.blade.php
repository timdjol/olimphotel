@extends('auth/layouts.master')

@section('title', 'Консоль')

@section('content')

<div class="page admin statistic">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                @include('auth/layouts.sidebar')
            </div>
            <div class="col-md-9">
                @if(session()->has('success'))
                    <p class="alert alert-success">{{ session()->get('success') }}</p>
                @endif
                @if(session()->has('warning'))
                    <p class="alert alert-warning">{{ session()->get('warning') }}</p>
                @endif
                <h1>Добро пожаловать {{ $users->name }}</h1>
                    <div class="position">Роль:
                        @if($users->is_admin == 1)
                            Администратор
                        @elseif($users->is_admin == 2)
                            Менеджер
                        @elseif($users->is_admin == 3)
                            Бухгалтер
                        @elseif($users->is_admin == 4)
                            Менеджер Отеля
                        @else
                            Пользователь
                        @endif
                    </div>
                    <h3>Статистика</h3>
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="statistic-item">
                            <h4>Количество <br> бронирований</h4>
                            <div class="num">{{ $books->count() }}</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="statistic-item">
                            <h4>Количество <br> отелей</h4>
                            <div class="num">{{ $hotels->count() }}</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="statistic-item">
                            <h4>Количество <br> номеров</h4>
                            <div class="num">{{ $rooms->count() }}</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="statistic-item">
                            <h4>Количество <br> страниц</h4>
                            <div class="num">{{ $pages->count() }}</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="statistic-item">
                            <h4>Количество <br> пользователей</h4>
                            <div class="num">{{ $users->count() }}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
