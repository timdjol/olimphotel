@extends('auth.layouts.master')

@isset($status)
    @section('title', 'Редактировать страницу' . $status->title)
@else
    @section('title', 'Создать страницу')
@endisset

@section('content')

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    @include('auth.layouts.sidebar')
                </div>
                <div class="col-md-9">
                    @isset($status)
                        <h1>Редактировать статус {{ $status->title }}</h1>
                    @else
                        <h1>Создать статус</h1>
                    @endisset
                    <form method="post"
                          @isset($status)
                              action="{{ route('statuses.update', $status) }}"
                          @else
                              action="{{ route('statuses.store') }}"
                            @endisset
                    >
                        @isset($status)
                            @method('PUT')
                        @endisset
                        @error('title')
                        <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                        <div class="form-group">
                            <label for="">Заголовок</label>
                            <input type="text" name="title" value="{{ old('title', isset($status) ? $status->title :
                             null) }}">
                        </div>
                        @error('title_en')
                        <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                        <div class="form-group">
                            <label for="">Заголовок EN</label>
                            <input type="text" name="title_en" value="{{ old('title_en', isset($status) ?
                                $status->title_en : null) }}">
                        </div>
                        @csrf
                        <button class="more">Отправить</button>
                        <a href="{{url()->previous()}}" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection
