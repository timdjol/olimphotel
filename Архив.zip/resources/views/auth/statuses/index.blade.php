@extends('auth.layouts.master')

@section('title', 'Статусы')

@section('content')

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    @include('auth.layouts.sidebar')
                </div>
                <div class="col-md-9">
                    @if(session()->has('success'))
                        <p class="alert alert-success">{{ session()->get('success') }}</p>
                    @endif
                    @if(session()->has('warning'))
                        <p class="alert alert-warning">{{ session()->get('warning') }}</p>
                    @endif
                    <div class="row">
                        <div class="col-md-7">
                            <h1>Статусы</h1>
                        </div>
                        <div class="col-md-5">
                            <a class="btn add" href="{{ route('statuses.create') }}">Добавить</a>
                        </div>
                    </div>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Название</th>
                            <th>Name</th>
                            <th>Действия</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($statuses as $status)
                            <tr>
                                <td>{{ $status->title }}</td>
                                <td>{{ $status->title_en }}</td>
                                <td>
                                    <form action="{{ route('statuses.destroy', $status) }}" method="post">
                                        <ul>
                                            <li><a class="btn view" href="{{ route('statuses.show', $status)
                                            }}">Открыть</a></li>
                                            <li><a class="btn edit" href="{{ route('statuses.edit', $status)
                                            }}">Редактировать</a></li>
                                            @csrf
                                            @method('DELETE')
                                            <button class="btn delete">Удалить</button>
                                        </ul>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

@endsection
