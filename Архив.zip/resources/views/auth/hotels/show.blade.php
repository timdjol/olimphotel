@extends('auth.layouts.master')

@section('title', 'Отель ' . $hotel->title)

@section('content')

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    @include('auth.layouts.sidebar')
                </div>
                <div class="col-md-9">
                    <h1>{{ $hotel->title }}</h1>
                    <table class="table">
                        <tr>
                            <td>Название EN</td>
                            <td>{{ $hotel->title_en }}</td>
                        </tr>
                        <tr>
                            <td>Описание</td>
                            <td>{!! $hotel->description !!}</td>
                        </tr>
                        <tr>
                            <td>Описание EN</td>
                            <td>{!! $hotel->description_en  !!}</td>
                        </tr>
                        <tr>
                            <td>Стоимость завтрака</td>
                            <td>{{ $hotel->breakfast }} сом</td>
                        </tr>
                        <tr>
                            <td>Время заезда</td>
                            <td>{{ $hotel->checkin }}</td>
                        </tr>
                        <tr>
                            <td>Время выезда</td>
                            <td>{{ $hotel->checkout }}</td>
                        </tr>
                        <tr>
                            <td>Номер телефона</td>
                            <td>{{ $hotel->phone }}</td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td>{{ $hotel->email }}</td>
                        </tr>
                        <tr>
                            <td>Адрес</td>
                            <td>{{ $hotel->address }}</td>
                        </tr>
                        <tr>
                            <td>Изображение</td>
                            <td><img src="{{ Storage::url($hotel->image) }}"></td>
                        </tr>
                    </table>
                    <script src="https://maps.api.2gis.ru/2.0/loader.js"></script>
                    <div id="map" style="width: 100%; height: 500px;"></div>
                    <script>
                        DG.then(function () {
                            var map = DG.map('map', {
                                center: [{{ $hotel->lat }}, {{ $hotel->lng }}],
                                zoom: 16
                            });

                            DG.marker([{{ $hotel->lat }}, {{ $hotel->lng }}], { scrollWheelZoom: false })
                                .addTo(map)
                                .bindLabel('{{ $hotel->title }}', {
                                    static: true
                                });
                        });
                    </script>
                </div>
            </div>
        </div>
    </div>

@endsection
