@extends('auth.layouts.master')

@section('title', 'Номера')

@section('content')

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    @include('auth.layouts.sidebar')
                </div>
                <div class="col-md-9">
                    @if(session()->has('success'))
                        <p class="alert alert-success">{{ session()->get('success') }}</p>
                    @endif
                    @if(session()->has('warning'))
                        <p class="alert alert-warning">{{ session()->get('warning') }}</p>
                    @endif
                    <h1>Номера</h1>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Изображение</th>
                            <th>Название</th>
                            <th>Отель</th>
                            <th>Цена</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($rooms as $room)
                            <tr>
                                <td><img src="{{ Storage::url($room->image) }}" alt="" width="100px"></td>
                                <td>{{ $room->title }}</td>
                                <td>{{ $room->hotel->title }}</td>
                                <td>{{ $room->price }} сом</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    {{ $rooms->links('pagination::bootstrap-4') }}
                </div>
            </div>
        </div>
    </div>

@endsection
