@extends('auth.layouts.master')

@section('title', 'Бронирование')

@section('content')

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    @include('auth.layouts.sidebar')
                </div>
                <div class="col-md-9">
                    <h1>Бронирование</h1>
                    <table>
                        <tr>
                            <th>Отель</th>
                            <th>Номер</th>
                            <th>ФИО</th>
                            <th>Телефон</th>
                            <th>Email</th>
                            <th>Кол-во</th>
                            <th>Сумма</th>
                            <th>Дата заезда</th>
                            <th>Дата выезда</th>
                        </tr>
                        <tbody>
                        @foreach($bookings as $booking)
                            <tr>
                                <td>
                                    @php
                                        $hotel = \App\Models\Hotel::where('id', $booking->hotel_id)->firstOrFail();
                                    @endphp
                                    {{ $hotel->title }}
                                </td>
                                <td>
                                    @php
                                        $room = \App\Models\Room::where('id', $booking->room_id)->firstOrFail();
                                    @endphp
                                    {{ $room->title }}
                                </td>
                                <td>{{ $booking->title }}</td>
                                <td><a href="tel:{{ $booking->phone }}">{{ $booking->phone }}</a></td>
                                <td><a href="mailto:{{ $booking->email }}">{{ $booking->email }}</a></td>
                                <td>{{ $booking->count }}</td>
                                <td>{{ $booking->sum }}</td>
                                <td>{{ $booking->showStartDate() }}</td>
                                <td>{{ $booking->showEndDate() }}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <style>
        table th, table td {
            font-size: 14px;
            line-height: 1.2;
        }

        table a {
            color: #0163b4;
            text-decoration: none;
        }
    </style>

@endsection
