@extends('auth.layouts.master')

@section('title', 'Отели')

@section('content')

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    @include('auth.layouts.sidebar')
                </div>
                <div class="col-md-9">
                    @if(session()->has('success'))
                        <p class="alert alert-success">{{ session()->get('success') }}</p>
                    @endif
                    @if(session()->has('warning'))
                        <p class="alert alert-warning">{{ session()->get('warning') }}</p>
                    @endif
                    <div class="row align-items-center">
                        <div class="col-md-7">
                            <h1>Отели</h1>
                        </div>
                        <div class="col-md-5">
                            <div class="btn-wrap">
                                <a class="btn add" href="{{ route('manager.hotels.create') }}">Добавить</a>
                            </div>
                        </div>
                    </div>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Изображение</th>
                            <th>Название</th>
                            <th>Действия</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($hotels as $hotel)
                            <tr>
                                <td><img src="{{ Storage::url($hotel->image) }}" alt="" width="100px"></td>
                                <td>{{ $hotel->title }}</td>
                                <td>
                                    <form action="{{ route('manager.hotels.destroy', $hotel) }}" method="post">
                                        <ul>
                                            <li><a class="btn view" href="{{ route('manager.hotels.show', $hotel)
                                            }}">Открыть</a></li>
                                            <li><a class="btn edit" href="{{ route('manager.hotels.edit', $hotel)
                                            }}">Редактировать</a></li>
                                            @csrf
                                            @method('DELETE')
                                            <button class="btn delete">Удалить</button>
                                        </ul>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    {{ $hotels->links('pagination::bootstrap-4') }}
                </div>
            </div>
        </div>
    </div>



@endsection
