@extends('auth.layouts.booking')

@section('title', 'Бронирование')

@section('content')

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    @include('auth.layouts.sidebar')
                </div>
                <div class="col-md-9">
{{--                    <div class="btn-wrap" style="margin-bottom: 20px">--}}
{{--                        <a href="{{ route('books.create') }}" class="more add">Добавить</a>--}}
{{--                    </div>--}}
                    <form action="{{ route('bookings.index') }}" method="get">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="">Отель</label>
                                    <select name="hotels" id="hotels">
                                        <option>Все отели</option>
                                        @foreach($hotels as $hotel)
                                            <option value="{{ $hotel->id }}" @selected(old('hotels') == $hotel->id)
                                            >{{ $hotel->title }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="">Выберите комнату</label>
                                    <select name="rooms" id="rooms">
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="">Кнопка</label>
                                <button class="more">Фильтр</button>
                            </div>
                        </div>
                    </form>
                    <div id='calendar'></div>
                    <table>
                        <tr>
                            <th>Отель</th>
                            <th>Номер</th>
                            <th>ФИО</th>
                            <th>Телефон</th>
                            <th>Сумма</th>
                            <th>Дата заезда</th>
                            <th>Дата выезда</th>
                            <th>Действия</th>
                        </tr>
                        <tbody>
                        @foreach($bookings as $booking)
                            <tr>
                                <td>
                                    @php
                                        $hotel = \App\Models\Hotel::where('id', $booking->hotel_id)->firstOrFail();
                                    @endphp
                                    {{ $hotel->title }}
                                </td>
                                <td>
                                    @php
                                        $room = \App\Models\Room::where('id', $booking->room_id)->firstOrFail();
                                    @endphp
                                    {{ $room->title }}
                                </td>
                                <td>{{ $booking->title }}</td>
                                <td><a href="tel:{{ $booking->phone }}">{{ $booking->phone }}</a></td>
                                <td>{{ $booking->sum }}</td>
                                <td>{{ $booking->showStartDate() }}</td>
                                <td>{{ $booking->showEndDate() }}</td>
                                <td>
                                    <form action="{{ route('books.destroy', $booking) }}" method="post">
                                        <ul>
                                            <li><a class="btn view" href="{{ route('books.show', $booking)
                                            }}">Открыть</a></li>
                                            @csrf
                                            @method('DELETE')
                                            <button class="btn delete">Удалить</button>
                                        </ul>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
{{--                    <h3>Удаленные брони</h3>--}}
{{--                    <table>--}}
{{--                        <tr>--}}
{{--                            <th>Отель</th>--}}
{{--                            <th>Номер</th>--}}
{{--                            <th>ФИО</th>--}}
{{--                            <th>Телефон</th>--}}
{{--                            <th>Email</th>--}}
{{--                            <th>Кол-во</th>--}}
{{--                            <th>Комментарий</th>--}}
{{--                            <th>Дата заезда</th>--}}
{{--                            <th>Дата выезда</th>--}}
{{--                        </tr>--}}
{{--                        <tbody>--}}
{{--                        @foreach($removed as $booking)--}}
{{--                            <tr>--}}
{{--                                <td>--}}
{{--                                    @php--}}
{{--                                        $hotel = \App\Models\Hotel::where('id', $booking->hotel_id)->firstOrFail();--}}
{{--                                    @endphp--}}
{{--                                    {{ $hotel->title }}--}}
{{--                                </td>--}}
{{--                                <td>--}}
{{--                                    @php--}}
{{--                                        $room = \App\Models\Room::where('id', $booking->room_id)->firstOrFail();--}}
{{--                                    @endphp--}}
{{--                                    {{ $room->title }}--}}
{{--                                </td>--}}
{{--                                <td>{{ $booking->title }}</td>--}}
{{--                                <td><a href="tel:{{ $booking->phone }}">{{ $booking->phone }}</a></td>--}}
{{--                                <td><a href="mailto:{{ $booking->email }}">{{ $booking->email }}</a></td>--}}
{{--                                <td>{{ $booking->count }}</td>--}}
{{--                                <td>{{ $booking->comment }}</td>--}}
{{--                                <td>{{ $booking->showStartDate() }}</td>--}}
{{--                                <td>{{ $booking->showEndDate() }}</td>--}}
{{--                            </tr>--}}
{{--                        @endforeach--}}
{{--                        </tbody>--}}
{{--                    </table>--}}
                </div>
            </div>
            <div class="modal fade" tabindex="-1" role="dialog" id="show_modal">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3>Бронирование</h3>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">Закрыть</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-xs-12">
                                    <form>
                                        <input type="hidden" name="status" id="status" value="Забронирован">
{{--                                        <input type="hidden" name="price" id="price" value="{{ $room->price }}">--}}
{{--                                        <input type="hidden" name="pricec" id="pricec" value="{{ $room->pricec }}">--}}
                                        <div class="form-group">
                                            <label for="hotel_id">Выберите отель</label>
                                            <select name="hotel_id" id=hotel_id" required>
                                                <option>Выбрать</option>
                                                @foreach($hotels as $hotel)
                                                    <option value="{{ $hotel->id }}">{{ $hotel->title }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="room_id">Выберите номер</label>
                                            <select name="room_id" id="room_id" required>
                                                <option>Выбрать</option>
                                                @foreach($rooms as $room)
                                                    <option value="{{ $room->id }}">{{ $room->title }}</option>
                                                @endforeach
                                            </select>
                                            <div id="price" class="hidden">{{ $room->price }}</div>
                                            <div id="pricec" class="hidden">{{ $room->pricec }}</div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-xs-4" for="title">Ваше имя</label>
                                            <input type="text" class="form-control" name="title" id="title" required />
                                            <span id="titleError" class="text-danger"></span>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-xs-4" for="phone">Номер телефона</label>
                                            <input type="number" class="form-control" name="phone" id="phone" required>
                                            <div id="output" class="output"></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-xs-4" for="email">Email</label>
                                            <input type="email" class="form-control" name="email" id="email" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-xs-4" for="content">Комментарий</label>
                                            <input type="text" class="form-control" name="comment" id="comment" />
                                        </div>

                                        <div class="form-group">
                                            <label class="col-xs-4" for="count">Кол-во взрослых</label>
                                            <select name="count" id="count" required>
                                                <option value="0">Выбрать</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                                <option value="10">10</option>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-xs-4" for="countс">Кол-во детей</label>
                                            <select name="countc" id="countc" required>
                                                <option value="0">Выбрать</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for="">Стоимость</label>
                                            <input type="text" id="sum" name="sum" readonly>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-xs-4" for="start_d">Дата заезда:</label>
                                            <input type="text" name="start_d" readonly id="start_d" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-xs-4" for="end_d">Дата выезда</label>
                                            <input type="text" name="end_d" readonly id="end_d" />
                                        </div>
                                        <button class="more" id="saveBtn">Оформить бронь</button>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
        </div>
    </div>

    <style>
        table th, table td{
            font-size: 14px;
            line-height: 1.2;
        }
        table a{
            color: #0163b4;
            text-decoration: none;
        }
    </style>

@endsection
