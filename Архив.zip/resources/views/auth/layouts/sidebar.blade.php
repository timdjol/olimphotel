<div class="sidebar">
    <div class="logo">
        <a href="{{ route('dashboard')}}"><img src="{{ url('/') }}/img/logo.png" alt=""></a>
    </div>
    <ul>
        @admin
            <li @routeactive('dashboard')><a href="{{ route('dashboard')}}">Консоль</a></li>
            <li @routeactive('bookings.index')><a href="{{ route('bookings.index')}}">Бронирование</a></li>
            <li @routeactive('statuses.index')><a href="{{ route('statuses.index')}}">Статусы бронирования</a></li>
            <li @routeactive('hotels.index')><a href="{{ route('hotels.index')}}">Отели</a></li>
            <li @routeactive('rooms.index')><a href="{{ route('rooms.index')}}">Номера</a></li>
            <li @routeactive('users.index')><a href="{{ route('users.index')}}">Пользователи</a></li>
            <li @routeactive('pages.index')><a href="{{ route('pages.index')}}">Страницы</a></li>
            <li @routeactive('home')><a href="{{ route('home')}}">Главная</a></li>
            <li @routeactive('contacts.index')><a href="{{ route('contacts.index')}}">Контакты</a></li>
            <li @routeactive('profile.edit')><a href="{{ route('profile.edit') }}">Профиль</a></li>
        @endadmin
        @manager
            <li @routeactive('manager.dashboard')><a href="{{ route('manager.dashboard')}}">Консоль</a></li>
            <li @routeactive('manager.books.index')><a href="{{ route('manager.books.index')}}">Бронирование</a></li>
            <li @routeactive('manager.hotels.index')><a href="{{ route('manager.hotels.index')}}">Отели</a></li>
            <li @routeactive('manager.rooms.index')><a href="{{ route('manager.rooms.index')}}">Номера</a></li>
            <li @routeactive('manager.users.index')><a href="{{ route('manager.users.index')}}">Пользователи</a></li>
            <li @routeactive('manager.pages.index')><a href="{{ route('manager.pages.index')}}">Страницы</a></li>
            <li @routeactive('manager.contacts.index')><a href="{{ route('manager.contacts.index')}}">Контакты</a></li>
            <li><a href="{{ route('profile.edit') }}">Профиль</a></li>
        @endmanager
        @buh
            <li @routeactive('buh.dashboard')><a href="{{ route('buh.dashboard')}}">Консоль</a></li>
            <li @routeactive('buh.books.index')><a href="{{ route('buh.books.index')}}">Бронирование</a></li>
            <li @routeactive('buh.hotels.index')><a href="{{ route('buh.hotels.index')}}">Отели</a></li>
            <li @routeactive('buh.rooms.index')><a href="{{ route('buh.rooms.index')}}">Номера</a></li>
            <li><a href="{{ route('profile.edit') }}">Профиль</a></li>
        @endbuh
        @hotel
            <li @routeactive('hotel.dashboard')><a href="{{ route('hotel.dashboard')}}">Консоль</a></li>
            <li @routeactive('hotel.books.index')><a href="{{ route('hotel.books.index')}}">Бронирование</a></li>
            <li @routeactive('hotel.hotels.index')><a href="{{ route('hotel.hotels.index')}}">Отели</a></li>
            <li @routeactive('hotel.rooms.index')><a href="{{ route('hotel.rooms.index')}}">Номера</a></li>
            <li><a href="{{ route('profile.edit') }}">Профиль</a></li>
        @endhotel
    </ul>
</div>
