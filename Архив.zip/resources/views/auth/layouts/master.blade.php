<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>@yield('title') - SilkWayTravel</title>
    <link rel="icon" href="{{route('index')}}/img/favicon.png">
    <link rel="apple-touch-icon" sizes="180x180" href="{{route('index')}}/img/favicon.png">
    <link rel="stylesheet" href="/css/main.min.css">
    <link rel="stylesheet" href="{{route('index')}}/css/admin.css">
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>

<header>
    <div class="head">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <nav>
                        <a href="#" class="toggle-mnu d-xl-none d-lg-none"><span></span></a>
                        <ul>
                            <li class="current"><a href="{{ route('homepage') }}" target="_blank">Перейти на
                                    сайт</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-md-6">
                    <nav>
                        <ul>
                            @guest
                                {{--                                <li><a href="{{route('register')}}">Регистрация</a></li>--}}
                                <li><a href="{{route('login')}}">Войти</a></li>
                            @endguest
                            @auth
                                <li>Добро пожаловать "{{ \Illuminate\Support\Facades\Auth::user()->name }}"</li>
                                <li><a href="{{ route('get-logout') }}">Выйти</a></li>
                            @endauth
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</header>

@yield('content')

<footer>
    <div class="copy">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p>SilkWayTravel {{ date('Y') }}</p>
                </div>
            </div>
        </div>
    </div>
</footer>


</body>
</html>
