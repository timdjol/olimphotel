<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Book;
use App\Models\Hotel;
use App\Models\Room;
use Illuminate\Http\Request;

class BookingController extends Controller
{
    public function index()
    {
        $bookings = Book::all();


        $hotel_id = (int) request()->hotels;
        $room_id = (int) request()->rooms;
        if(request()->hotels){
            $bookings = Book::where('hotel_id', $hotel_id)->get();
        }
        if(request()->rooms){
            $bookings = Book::where('hotel_id', $hotel_id)->where('room_id', $room_id)->get();
        }


        $hotels = Hotel::all();
        $rooms = Room::all();
        $events = array();

//        $time_from = '2024-03-21';
//        $time_to = '2024-03-22';
//        $count = 5;
//        $rooms = Room::whereNotIn('id', function($query) use ($time_from, $time_to) {
//            $query->from('books')
//                ->select('room_id')
//                ->where('count', 5)
//                ->where('start_d', '<=', $time_to)
//                ->where('end_d', '>=', $time_from);
//        })->get();

        $removed = Book::onlyTrashed()->get();

        foreach ($bookings as $booking){
//            $color = null;
//            if($booking->room_id == 1){
//                $color = 'red';
//            }
//            if($booking->room_id == 2){
//                $color = 'orange';
//            }
//            if($booking->room_id == 3){
//                $color = 'green';
//            }
//            if($booking->room_id == 4){
//                $color = 'purple';
//            }

            $events[] = [
                'id' => $booking->id,
                'hotel_id' => $booking->hotel_id,
                'room_id' => $booking->room_id,
                'title' => $booking->title,
                'phone' => $booking->phone,
                'email' => $booking->email,
                'comment' => $booking->comment,
                'count' => $booking->count,
                'countc' => $booking->countc,
                'sum' => $booking->sum,
                'status' => $booking->status,
                'start' => $booking->start_d,
                'end' => $booking->end_d,
                //'color' => $color
            ];
        }
        return view('auth.bookings.index', compact('events', 'bookings', 'removed', 'hotels', 'rooms'));
    }

    public function create()
    {
        $hotels = Hotel::all();
        $rooms = Room::all();
        return view('auth.bookings.form', compact('hotels', 'rooms'));
    }

    public function store(Request $request)
    {
//        $request->validate([
//           'title' => 'required|string'
//        ]);
        $params = $request->all();
        //dd($params);
        $booking = Book::create($params);
        return response()->json($booking);
    }


    public function edit(Book $booking)
    {
        return view('auth.bookings.form', compact('booking'));
    }

    public function update(Request $request, $id)
    {
        $booking = Book::find($id);
        if(!$booking){
            return response()->json([
                'error' => 'Unable to locate the event'
            ], 404);
        }
        $booking->update([
            'start_d' => $request->start_d,
            'end_d' => $request->end_d
        ]);
        return response()->json('Event updated');
    }

    public function destroy(Request $request, $id)
    {
        $booking = Book::find($id);
        if(!$booking){
            return response()->json([
                'error' => 'Unable to locate the event'
            ], 404);
        }
        $booking->delete();
        $room = Room::where('id', $request->room_id)->firstOrFail();
        $room->increment('count', $request->count);
        return $id;
    }

    public function fetchRoom(Request $request)
    {
        $data['rooms'] = Room::where("hotel_id", $request->hotel_id)->get();
        return response()->json($data);
    }

}
