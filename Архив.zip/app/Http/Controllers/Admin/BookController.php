<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Book;
use App\Models\Hotel;
use App\Models\Room;
use http\Client\Request;


class BookController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $books = Book::paginate(10);
        return view('auth.bookings.index', compact('books'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $hotels = Hotel::all();
        return view('auth.bookings.form', compact('hotels'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $params = $request->all();
        Book::create($params);
        session()->flash('success', 'Бронирование ' . $request->title . ' добавлено');
        return redirect()->route('bookings.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(Book $book)
    {
        $hotel = Hotel::where('id', $book->hotel_id)->firstOrFail();
        $room = Room::where('id', $book->room_id)->firstOrFail();
        return view('auth.books.show', compact('book', 'hotel', 'room'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Book $book)
    {
        $hotels = Hotel::all();
        return view('auth.books.form', compact('book', 'hotels'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Book $book)
    {
        $params = $request->all();
        $book->update($params);
        session()->flash('success', 'Бронирование ' . $book->title . ' обновлено');
        return redirect()->route('bookings.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Book $book)
    {
        $book->delete();
        session()->flash('success', 'Бронирование ' . $book->title . ' удалено');
        return redirect()->route('bookings.index');
    }
}
