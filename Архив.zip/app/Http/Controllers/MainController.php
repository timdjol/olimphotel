<?php

namespace App\Http\Controllers;

use App\Mail\ContactMail;
use App\Mail\HotelMail;
use App\Models\Order;
use App\Models\Room;
use App\Models\Slider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Mail;

class MainController extends Controller
{
    public function index()
    {
        return view('index');
    }

    public function changeLocale($locale)
    {
        $availableLocales = ['ru', 'en'];
        if (!in_array($locale, $availableLocales)) {
            $locale = config('app.locale');
        }
        session(['locale' => $locale]);
        App::setLocale($locale);
        return redirect()->back();
    }

    public function contact_mail(Request $request)
    {
        Mail::to('info@timdjol.com')->send(new ContactMail($request));
        return redirect()->route('contactspage');
    }

    public function hotel_mail(Request $request)
    {
        $params = $request->all();
        Order::create($params);
        Mail::to('info@timdjol.com')->send(new HotelMail($request));
        return redirect()->route('index');
    }


//    public function search()
//    {
//        $title = $_GET['search'];
//        $search = Product::query()
//            ->where('title', 'like', '%'.$title.'%')
//            ->orWhere('title_en', 'like', '%'.$title.'%')
//            ->get();
//        return view('search', compact('search'));
//    }


}
