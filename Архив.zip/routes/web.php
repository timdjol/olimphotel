<?php


use App\Http\Controllers\Admin\BookingController;
use App\Http\Controllers\Admin\HotelController;
use App\Http\Controllers\Admin\RoomController;
use App\Http\Controllers\CalendarController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MainController;
use App\Http\Controllers\PageController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('locale/{locale}', 'App\Http\Controllers\MainController@changeLocale')->name('locale');
Route::get('/logout', 'App\Http\Controllers\ProfileController@logout')->name('get-logout');


Route::middleware('set_locale')->group(function ()
{
    Route::middleware('auth')->group(function ()
    {
        Route::group([
            "prefix" => "admin",
        ], function ()
        {
            Route::group(["middleware" => "is_admin"], function ()
            {
                Route::get('/dashboard',
                    [App\Http\Controllers\Admin\DashboardController::class, 'dashboard'])->name('dashboard');
                Route::get('/home', [App\Http\Controllers\Admin\HomeController::class, 'home'])->name('home');
                Route::resource("contacts", "App\Http\Controllers\Admin\ContactController");
                Route::resource("pages", "App\Http\Controllers\Admin\PageController");
                Route::resource("sliders", "App\Http\Controllers\Admin\SliderController");
                Route::resource("vantages", "App\Http\Controllers\Admin\VantageController");
                //Route::resource("faqs", "App\Http\Controllers\Admin\FaqController");
                Route::resource("hotels", "App\Http\Controllers\Admin\HotelController");
                //Route::resource("orders", "App\Http\Controllers\Admin\OrderController");
                Route::resource("rooms", "App\Http\Controllers\Admin\RoomController");
                Route::resource("statuses", "App\Http\Controllers\Admin\StatusController");
                Route::resource("books", "App\Http\Controllers\Admin\BookController");
                Route::resource("users", "App\Http\Controllers\Admin\UserController");

                Route::get('/hotels/{status?}/{show_result?}/{s_query?}', [HotelController::class, 'index'])->name
                ('hotels.index');
                Route::get('/rooms/{status?}/{show_result?}/{s_query?}', [RoomController::class, 'index'])->name
                ('rooms.index');

                Route::get('/bookings/index', [BookingController::class, 'index'])->name('bookings.index');
                Route::get('/bookings/create', [BookingController::class, 'create'])->name('bookings.create');
                Route::post('/bookings/store', [BookingController::class, 'store'])->name('bookings.store');
                Route::put('/bookings/edit/{id}', [BookingController::class, 'edit'])->name('bookings.edit');
                Route::patch('/bookings/update/{id}', [BookingController::class, 'update'])->name('bookings.update');
                Route::delete('/bookings/destroy/{id}',
                    [BookingController::class, 'destroy'])->name('bookings.destroy');

            });

        });

        Route::group([
            "prefix" => "manager",
            "as" => "manager.",
        ], function ()
        {
            Route::group(["middleware" => "is_manager"], function ()
            {
                Route::get('/dashboard',
                    [App\Http\Controllers\Admin\DashboardController::class, 'dashboard'])->name('dashboard');
                Route::resource("books", "App\Http\Controllers\Manager\BookController");
                Route::get('/home', [App\Http\Controllers\Admin\HomeController::class, 'home'])->name('home');
                Route::resource("contacts", "App\Http\Controllers\Manager\ContactController");
                Route::resource("pages", "App\Http\Controllers\Manager\PageController");
                Route::resource("hotels", "App\Http\Controllers\Manager\HotelController");
                Route::resource("rooms", "App\Http\Controllers\Manager\RoomController");
                Route::resource("users", "App\Http\Controllers\Manager\UserController");
                Route::get('/bookings/index', [BookingController::class, 'index'])->name('bookings.index');
                Route::get('/bookings/create', [BookingController::class, 'create'])->name('bookings.create');
                Route::post('/bookings/store', [BookingController::class, 'store'])->name('bookings.store');
                Route::put('/bookings/edit/{id}', [BookingController::class, 'edit'])->name('bookings.edit');
                Route::patch('/bookings/update/{id}', [BookingController::class, 'update'])->name('bookings.update');
                Route::delete('/bookings/destroy/{id}',
                    [BookingController::class, 'destroy'])->name('bookings.destroy');

                Route::get('/hotels/{status?}/{show_result?}/{s_query?}', [HotelController::class, 'index'])->name
                ('hotels.index');
            });
        });

        Route::group([
            "prefix" => "buh",
            "as" => "buh.",
        ], function ()
        {
            Route::group(["middleware" => "is_buh"], function ()
            {
                Route::get('/dashboard',
                    [App\Http\Controllers\Admin\DashboardController::class, 'dashboard'])->name('dashboard');
                Route::get('/books', [\App\Http\Controllers\Buh\BookController::class, 'index'])->name('books.index');
                Route::resource("hotels", "App\Http\Controllers\Buh\HotelController");
                Route::resource("rooms", "App\Http\Controllers\Buh\RoomController");
            });
        });

        Route::group([
            "prefix" => "hotel",
            "as" => "hotel.",
        ], function ()
        {
            Route::group(["middleware" => "is_hotel"], function ()
            {
                Route::get('/dashboard',
                    [App\Http\Controllers\Admin\DashboardController::class, 'dashboard'])->name('dashboard');
                Route::get('/books', [\App\Http\Controllers\Hotel\BookController::class, 'index'])->name('books.index');
                Route::resource("hotels", "App\Http\Controllers\Hotel\HotelController");
                Route::resource("rooms", "App\Http\Controllers\Hotel\RoomController");
                Route::resource("books", "App\Http\Controllers\Hotel\BookController");
            });
        });

        Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
        Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
        Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    });

    require __DIR__ . '/auth.php';


    Route::get('/', [MainController::class, 'index'])->name('index');
    Route::get('/homepage', [PageController::class, 'homepage'])->name('homepage');
    Route::get('/books/index/{id}', [CalendarController::class, 'index'])->name('books.index');
    Route::post('/books', [CalendarController::class, 'store'])->name('books.store');
    Route::patch('/books/update/{id}', [CalendarController::class, 'update'])->name('books.update');
    Route::delete('/books/delete/{id}', [CalendarController::class, 'delete'])->name('books.delete');

    Route::post('/api/fetch-rooms', [BookingController::class, 'fetchRoom']);

    Route::get('/hotels', [PageController::class, 'hotels'])->name('hotels');
    //Route::get('/rooms', [PageController::class, 'allrooms'])->name('allrooms');
    Route::get('/allrooms/{hotel?}/{price_from?}/{price_to?}/{count?}/{date_from?}/{date_to?}', [
        PageController::class,
        'allrooms'
    ])->name
    ('allrooms');


    Route::get('/about', [PageController::class, 'about'])->name('about');
    Route::get('/contactspage', [PageController::class, 'contactspage'])->name('contactspage');

    //email
    Route::post('contact_mail', [MainController::class, 'contact_mail'])->name('contact_mail');
    Route::post('hotel_mail', [MainController::class, 'hotel_mail'])->name('hotel_mail');
    //Route::get('/search', [MainController::class, 'search'])->name('search');

    Route::get('/{hotel}', [PageController::class, 'hotel'])->name('hotel');
    Route::get('/{hotel}/{rooms}', [PageController::class, 'room'])->name('room');

});

