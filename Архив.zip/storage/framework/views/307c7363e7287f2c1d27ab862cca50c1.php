<?php $__env->startSection('title', 'Логин'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin login">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3 col-md-12">
                    <h2>Авторизация</h2>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">email</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-group">
                            <label for="">Email</label>
                            <input type="email" name="email" value="<?php echo e(old('email', isset($user) ? $user->email :
                             null)); ?>">
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">password</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-group">
                            <label for="">Пароль</label>
                            <input type="password" name="password" id="password" autocomplete="current-password"
                                   value="<?php echo e(old('password', isset($user) ? $user->password : null)); ?>">
                            <div class="checkbox">
                                <input type="checkbox" id="checkbox"><label for="checkbox">Показать пароль</label>
                            </div>
                            <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
                            <script>
                                $(document).ready(function(){
                                    $('#checkbox').on('change', function(){
                                        $('#password').attr('type',$('#checkbox').prop('checked')==true?"text":"password");
                                    });
                                });
                            </script>

                            <style>
                                .checkbox{
                                    margin-top: 10px;
                                }
                                .checkbox label{
                                    display: inline-block;
                                }
                            </style>

                        </div>
                        <!-- Remember Me -->






                        <div class="form-group">
                            <?php if(Route::has('password.request')): ?>
                                <a href="<?php echo e(route('password.request')); ?>">
                                    Забыли пароль?
                                </a>
                            <?php endif; ?>
                        </div>
                        <?php echo csrf_field(); ?>
                        <button class="more">Войти</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/login.blade.php ENDPATH**/ ?>