<?php $__env->startSection('title', 'Экскурсии'); ?>

<?php $__env->startSection('content'); ?>

    <div class="pagetitle" style="background-image: url(<?php echo e(url('/')); ?>/img/111.jpg)">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 data-aos="fade-up" data-aos-duration="2000"><?php echo app('translator')->get('main.travel'); ?></h1>
                    <ul class="breadcrumbs">
                        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                        <li>></li>
                        <li><?php echo app('translator')->get('main.travel'); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="page travel">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $travel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-4 col-6" data-aos="zoom-in" data-aos-duration="2000">
                        <div class="travel-item" style="background-image: url(<?php echo e(Storage::url($trav->image)); ?>)">
                            <a href="<?php echo e(route('travel', $trav->code)); ?>">
                                <div class="overlay"></div>
                                <h4><?php echo e($trav->__('title')); ?></h4>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="rent">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 data-aos="fade-up" data-aos-duration="2000"><?php echo app('translator')->get('main.kind_tour'); ?></h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <ul class="tabs">
                    <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->iteration == 1): ?>
                                <li class="tab-link current" data-tab="tab-<?php echo e($loop->iteration); ?>"><?php echo e($rent->__('title')); ?></li>
                            <?php else: ?>
                                <li class="tab-link" data-tab="tab-<?php echo e($loop->iteration); ?>"><?php echo e($rent->__('title')); ?></li>
                            <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                        <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->iteration == 1): ?>
                                <div class="tab-content current" id="tab-<?php echo e($loop->iteration); ?>">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="img" style="background-image: url(<?php echo e(Storage::url($rent->image)); ?>)"></div>
                                        </div>
                                        <div class="col-md-7">
                                            <h4><?php echo e($rent->__('title')); ?></h4>
                                            <?php echo $rent->__('description'); ?>

                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="tab-content" id="tab-<?php echo e($loop->iteration); ?>">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="img" style="background-image: url(<?php echo e(Storage::url($rent->image)); ?>)"></div>
                                        </div>
                                        <div class="col-md-7">
                                            <h4><?php echo e($rent->__('title')); ?></h4>
                                            <?php echo $rent->__('description'); ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/olimp-app/resources/views/pages/category-travel.blade.php ENDPATH**/ ?>