<?php $__env->startSection('title', 'Страницы'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(session()->has('success')): ?>
                        <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
                    <?php endif; ?>
                    <?php if(session()->has('warning')): ?>
                        <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-md-7">
                            <h1>Страницы</h1>
                        </div>
                        <div class="col-md-5">
                            <a class="btn add" href="<?php echo e(route('pages.create')); ?>">Добавить</a>
                        </div>
                    </div>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Код</th>
                            <th>Название</th>
                            <th>Действия</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($page->code); ?></td>
                                <td><?php echo e($page->title); ?></td>
                                <td>
                                    <form action="<?php echo e(route('pages.destroy', $page)); ?>" method="post">
                                        <ul>
                                            <li><a class="btn view" href="<?php echo e(route('pages.show', $page)); ?>">Открыть</a></li>
                                            <li><a class="btn edit" href="<?php echo e(route('pages.edit', $page)); ?>">Редактировать</a></li>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn delete">Удалить</button>
                                        </ul>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($pages->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/pages/index.blade.php ENDPATH**/ ?>