<?php $__env->startSection('title', 'Бронирование'); ?>

<?php $__env->startSection('content'); ?>

<div class="page booking">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 offset-lg-1 col-md-12">
                <h1><?php echo e($room->__('title')); ?></h1>
                <div id='calendar'></div>
            </div>
        </div>
        <div class="modal fade" tabindex="-1" role="dialog" id="show_modal">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3><?php echo app('translator')->get('main.booking'); ?></h3>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true"><?php echo app('translator')->get('main.close'); ?></span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-xs-12">
                                <?php if($room->count > 0): ?>
                                    <form method="post" action="<?php echo e(route('books.store')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div id="price" class="hidden"><?php echo e($room->price); ?></div>
                                        <div id="pricec" class="hidden"><?php echo e($room->pricec); ?></div>
                                        <input type="hidden" class="form-control" name="room_id" id="room_id"
                                               value="<?php echo e($id); ?>"/>
                                        <input type="hidden" class="form-control" name="hotel_id" value="<?php echo e($room->hotel_id); ?>"/>
                                        <div class="form-group">
                                            <label class="col-xs-4" for="title"><?php echo app('translator')->get('main.name'); ?></label>
                                            <input type="text" class="form-control" name="title" id="title" />
                                            <span id="titleError" class="text-danger"></span>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-xs-4" for="phone"><?php echo app('translator')->get('main.phone'); ?></label>
                                            <input type="number" class="form-control" name="phone" id="phone">
                                            <div id="output"></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-xs-4" for="email"><?php echo app('translator')->get('main.email'); ?></label>
                                            <input type="email" class="form-control" name="email" id="email" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-xs-4" for="content"><?php echo app('translator')->get('main.message'); ?></label>
                                            <input type="text" class="form-control" name="comment" id="comment" />
                                        </div>

                                        <div class="form-group">
                                            <label class="col-xs-4" for="count"><?php echo app('translator')->get('main.count'); ?></label>
                                            <select name="count" id="count" required>
                                                <option><?php echo app('translator')->get('main.choose'); ?></option>
                                                <?php for($i=1; $i <= $room->count; $i++): ?>
                                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-xs-4" for="countс"><?php echo app('translator')->get('main.countc'); ?></label>
                                            <select name="countc" id="countc" required>
                                                <option value="0"><?php echo app('translator')->get('main.choose'); ?></option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for=""><?php echo app('translator')->get('main.amount'); ?></label>
                                            <input type="text" id="sum" name="sum" readonly>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-xs-4" for="start_d"><?php echo app('translator')->get('main.start_d'); ?></label>
                                            <input type="text" name="start_d" readonly id="start_d" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-xs-4" for="end_d"><?php echo app('translator')->get('main.end_d'); ?></label>
                                            <input type="text" name="end_d" readonly id="end_d" />
                                        </div>
                                        <input type="hidden" name="status" id="status" value="<?php echo app('translator')->get('main.booked'); ?>">

                                        <button class="more" id="saveBtn"><?php echo app('translator')->get('main.order'); ?></button>
                                    </form>
                                <?php else: ?>
                                    <div class="alert alert-danger"><?php echo app('translator')->get('main.empty'); ?></div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
    </div>
</div>

<style>
    .fc-title{
        color: transparent;
    }
    .fc-title .busy{
        color: #fff;
    }
</style>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.booking', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/pages/books.blade.php ENDPATH**/ ?>