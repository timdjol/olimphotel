<?php $__env->startSection('title', 'Контакты'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(session()->has('success')): ?>
                        <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
                    <?php endif; ?>
                    <?php if(session()->has('warning')): ?>
                        <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-md-7">
                            <h1>Контакты</h1>
                        </div>
                    </div>
                    <table class="table">
                        <tbody>
                        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>Номер телефона</td>
                                <td><?php echo e($contact->phone); ?></td>
                            </tr>
                            <tr>
                                <td>Номер телефона #2</td>
                                <td><?php echo e($contact->phone2); ?></td>
                            </tr>
                            <tr>
                                <td>Email</td>
                                <td><?php echo e($contact->email); ?></td>
                            </tr>
                            <tr>
                                <td>Адрес</td>
                                <td><?php echo e($contact->address); ?></td>
                            </tr>
                            <tr>
                                <td>Адрес EN</td>
                                <td><?php echo e($contact->address_en); ?></td>
                            </tr>
                            <tr>
                                <td>WhatsApp</td>
                                <td><?php echo e($contact->whatsapp); ?></td>
                            </tr>
                            <tr>
                                <td>Telegram</td>
                                <td><?php echo e($contact->telegram); ?></td>
                            </tr>
                            <tr>
                                <td>Instagram</td>
                                <td><?php echo e($contact->instagram); ?></td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <ul>
                                        <li><a class="btn view" href="<?php echo e(route('contacts.edit', $contact)); ?>">Редактировать</a></li>
                                    </ul>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/olimp-app/resources/views/auth/contacts/index.blade.php ENDPATH**/ ?>