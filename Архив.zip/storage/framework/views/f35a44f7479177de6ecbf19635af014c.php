<table>
    <tr>
        <td><?php echo app('translator')->get('main.travel'); ?></td>
        <td><?php echo e($user->travel); ?></td>
    </tr>
    <tr>
        <td><?php echo app('translator')->get('main.what_kind'); ?></td>
        <td><?php echo e($user->choose); ?></td>
    </tr>
    <tr>
        <td><?php echo app('translator')->get('main.date'); ?></td>
        <td><?php echo e($user->dates); ?></td>
    </tr>
    <tr>
        <td><?php echo app('translator')->get('main.count'); ?></td>
        <td><?php echo e($user->count); ?></td>
    </tr>
    <tr>
        <td><?php echo app('translator')->get('main.name'); ?></td>
        <td><?php echo e($user->name); ?></td>
    </tr>
    <tr>
        <td><?php echo app('translator')->get('main.phone'); ?></td>
        <td><a href="tel:<?php echo e($user->phone); ?>"><?php echo e($user->phone); ?></a></td>
    </tr>
    <tr>
        <td>Email</td>
        <td><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></td>
    </tr>
</table>

<style>
    table{
        width: 100%;
    }
    table td{
        padding: 10px;
        border-top: 1px solid #ddd;
    }
</style><?php /**PATH /Users/timdjol/Sites/localhost/olimp-app/resources/views/mail/travel.blade.php ENDPATH**/ ?>