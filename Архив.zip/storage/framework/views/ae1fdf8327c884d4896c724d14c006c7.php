<?php if(isset($travel)): ?>
    <?php $__env->startSection('title', 'Редактировать экскурсию ' . $travel->name); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Создать экскурсию'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(isset($travel)): ?>
                        <h1>Редактировать экскурсию <?php echo e($travel->title); ?></h1>
                    <?php else: ?>
                        <h1>Создать экскурсию</h1>
                    <?php endif; ?>
                    <form method="post" enctype="multipart/form-data"
                          <?php if(isset($travel)): ?>
                              action="<?php echo e(route('travel.update', $travel)); ?>"
                          <?php else: ?>
                              action="<?php echo e(route('travel.store')); ?>"
                            <?php endif; ?>
                    >
                        <?php if(isset($travel)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-group">
                            <label for="">Заголовок</label>
                            <input type="text" name="title" value="<?php echo e(old('title', isset($travel) ? $travel->title :
                             null)); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Заголовок EN</label>
                            <input type="text" name="title_en" value="<?php echo e(old('title_en', isset($travel) ?
                                $travel->title_en :
                             null)); ?>">
                        </div>
                            <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="form-group">
                                <label for="">Описание</label>
                                <textarea name="description" id="editor" rows="3"><?php echo e(old('description', isset($travel) ?
                            $travel->description : null)); ?></textarea>
                            </div>
                            <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'description_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="form-group">
                                <label for="">Описание EN</label>
                                <textarea name="description_en" id="editor1" rows="3"><?php echo e(old('description_en', isset
                            ($travel) ?
                            $travel->description_en : null)); ?></textarea>
                            </div>
                            <script src="https://cdn.tiny.cloud/1/yxonqgmruy7kchzsv4uizqanbapq2uta96cs0p4y91ov9iod/tinymce/6/tinymce.min.js"
                                    referrerpolicy="origin"></script>
                            <script src="https://cdn.ckeditor.com/ckeditor5/35.1.0/classic/ckeditor.js"></script>
                            <script>
                                ClassicEditor
                                    .create(document.querySelector('#editor'))
                                    .catch(error => {
                                        console.error(error);
                                    });
                                ClassicEditor
                                    .create(document.querySelector('#editor1'))
                                    .catch(error => {
                                        console.error(error);
                                    });
                            </script>
                        <div class="form-group">
                            <label for="">Изображение</label>
                            <?php if(isset($travel->image)): ?>
                                <img src="<?php echo e(Storage::url($travel->image)); ?>" alt="">
                            <?php endif; ?>
                            <input type="file" name="image">
                        </div>
                        <?php echo csrf_field(); ?>
                        <button class="more">Отправить</button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/olimp-app/resources/views/auth/travel/form.blade.php ENDPATH**/ ?>