<?php $__env->startSection('title', $room->__('title')); ?>

<?php $__env->startSection('content'); ?>

    <div class="pagetitle" style="background-image: url(<?php echo e(url('/')); ?>/img/111.jpg)">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 data-aos="fade-up" data-aos-duration="2000"><?php echo app('translator')->get('main.rooms'); ?></h1>
                    <ul class="breadcrumbs">
                        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                        <li>></li>
                        <li><a href="<?php echo e(route('rooms')); ?>"><?php echo app('translator')->get('main.rooms'); ?></a></li>
                        <li>></li>
                        <li><?php echo e($room->__('title')); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="rooms single">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="fotorama" data-allowfullscreen="true" data-nav="thumbs" data-loop="true" data-autoplay="3000">
                        <img loading="lazy" src="<?php echo e(Storage::url($room->image)); ?>" alt="">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img loading="lazy" src="<?php echo e(Storage::url($image->image)); ?>" alt="">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-md-6" data-aos="fade-left" data-aos-duration="2000">
                    <h3><?php echo e($room->__('title')); ?></h3>
                    <div class="price"><?php echo app('translator')->get('main.price'); ?> <?php echo e($room->price); ?> <?php echo app('translator')->get('main.som'); ?></div>
                    <div class="btn-wrap">
                        <a href="<?php echo e(route('books.index', $room->id)); ?>" class="more"><?php echo app('translator')->get('main.book'); ?></a>
                        <?php if(session('locale')=='ru'): ?>
                            <a href="https://api.whatsapp.com/send?phone=<?php echo e($contacts->first()->whatsapp); ?>&text=Заявка
                        на номер <?php echo e($room->__('title')); ?>" class="more whatsapp" target="_blank"><?php echo app('translator')->get('main.book_whatsapp'); ?></a>
                        <?php else: ?>
                            <a href="https://api.whatsapp.com/send?phone=<?php echo e($contacts->first()
                            ->whatsapp); ?>&text=Booking room <?php echo e($room->__('title')); ?>" class="more whatsapp"
                               target="_blank"><?php echo app('translator')->get('main.book_whatsapp'); ?></a>
                        <?php endif; ?>
                    </div>
                    <?php echo $room->__('description'); ?>

                    <div class="servlisting">
                        <ul>
                            <?php if($room->isTv()): ?>
                                <li><a href="#" class="tooltip"><img src="<?php echo e(url('/')); ?>/img/tv.png"><span><?php echo app('translator')->get('main.tv'); ?></span></a></li>
                            <?php endif; ?>
                                <?php if($room->isCloset()): ?>
                                    <li><a href="#" class="tooltip"><img src="<?php echo e(url('/')); ?>/img/closet.png"><span><?php echo app('translator')->get('main.closet'); ?></span></a></li>
                                <?php endif; ?>
                                <?php if($room->isSafe()): ?>
                                    <li><a href="#" class="tooltip"><img src="<?php echo e(url('/')); ?>/img/security-box.png"><span><?php echo app('translator')->get('main.safe'); ?></span></a></li>
                                <?php endif; ?>
                                <?php if($room->isBar()): ?>
                                    <li><a href="#" class="tooltip"><img src="<?php echo e(url('/')); ?>/img/minibar.png"><span><?php echo app('translator')->get('main.bar'); ?></span></a></li>
                                <?php endif; ?>
                                <?php if($room->isCond()): ?>
                                    <li><a href="#" class="tooltip"><img src="<?php echo e(url('/')); ?>/img/air-conditioner.png"><span><?php echo app('translator')->get('main.cond'); ?></span></a></li>
                                <?php endif; ?>
                                <?php if($room->isCabinet()): ?>
                                    <li><a href="#" class="tooltip"><img src="<?php echo e(url('/')); ?>/img/bedside.png"><span><?php echo app('translator')->get('main.cabinet'); ?></span></a></li>
                                <?php endif; ?>
                                <?php if($room->isWtable()): ?>
                                    <li><a href="#" class="tooltip"><img src="<?php echo e(url('/')); ?>/img/desk.png"><span><?php echo app('translator')->get('main.wtable'); ?></span></a></li>
                                <?php endif; ?>
                        </ul>
                    </div>
                    <div class="share">
                        <div class="descr"><?php echo app('translator')->get('main.share'); ?></div>
                        <script src="https://yastatic.net/share2/share.js"></script>
                        <div class="ya-share2" data-curtain data-shape="round"
                             data-services="vkontakte,odnoklassniki,telegram,twitter,whatsapp,linkedin"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="rooms related">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo app('translator')->get('main.related'); ?></h2>
                </div>
            </div>
            <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($loop->iteration % 2): ?>
                    <div class="row rooms-item">
                        <div class="col-md-6" data-aos="fade-right" data-aos-duration="2000">
                            <a href="<?php echo e(route('room', $room->code)); ?>">
                                <div class="img" style="background-image: url(<?php echo e(Storage::url($room->image)); ?>)"></div>
                            </a>
                        </div>
                        <div class="col-md-6" data-aos="fade-left" data-aos-duration="2000">
                            <h3><?php echo e($room->__('title')); ?></h3>
                            <?php echo $room->__('description'); ?>

                            <div class="btn-wrap">
                                <a href="<?php echo e(route('room', $room->code)); ?>" class="more"><?php echo app('translator')->get('main.more'); ?></a>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="row rooms-item second">
                        <div class="col-md-6 order-lg-1 order-md-1 order-2" data-aos="fade-right" data-aos-duration="2000">
                            <div class="text-wrap">
                                <h3><?php echo e($room->__('title')); ?></h3>
                                <?php echo $room->__('description'); ?>

                                <div class="btn-wrap">
                                    <a href="<?php echo e(route('room', $room->code)); ?>" class="more"><?php echo app('translator')->get('main.more'); ?></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 order-lg-2 order-md-2 order-1" data-aos="fade-left" data-aos-duration="2000">
                            <a href="<?php echo e(route('room', $room->code)); ?>">
                                <div class="img" style="background-image: url(<?php echo e(Storage::url($room->image)); ?>)"></div>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/olimp-app/resources/views/pages/room.blade.php ENDPATH**/ ?>