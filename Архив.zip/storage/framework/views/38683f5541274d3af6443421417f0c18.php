<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('title'); ?> - SilkWayTravel</title>
    <link rel="icon" href="<?php echo e(route('index')); ?>/img/favicon.png">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(route('index')); ?>/img/favicon.png">
    <link rel="stylesheet" href="/css/main.min.css">
    <link rel="stylesheet" href="<?php echo e(route('index')); ?>/css/admin.css">
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>

<header>
    <div class="head">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <nav>
                        <a href="#" class="toggle-mnu d-xl-none d-lg-none"><span></span></a>
                        <ul>
                            <li class="current"><a href="<?php echo e(route('homepage')); ?>" target="_blank">Перейти на
                                    сайт</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-md-6">
                    <nav>
                        <ul>
                            <?php if(auth()->guard()->guest()): ?>
                                
                                <li><a href="<?php echo e(route('login')); ?>">Войти</a></li>
                            <?php endif; ?>
                            <?php if(auth()->guard()->check()): ?>
                                <li>Добро пожаловать "<?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?>"</li>
                                <li><a href="<?php echo e(route('get-logout')); ?>">Выйти</a></li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</header>

<?php echo $__env->yieldContent('content'); ?>

<footer>
    <div class="copy">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p>SilkWayTravel <?php echo e(date('Y')); ?></p>
                </div>
            </div>
        </div>
    </div>
</footer>


</body>
</html>
<?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/layouts/master.blade.php ENDPATH**/ ?>