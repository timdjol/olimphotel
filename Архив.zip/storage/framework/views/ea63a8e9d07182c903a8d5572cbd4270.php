<?php $__env->startSection('title', 'Консоль'); ?>

<?php $__env->startSection('content'); ?>

<div class="page admin dashboard">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <?php echo $__env->make('auth/layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-9">
                <?php if(session()->has('success')): ?>
                    <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
                <?php endif; ?>
                <?php if(session()->has('warning')): ?>
                    <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
                <?php endif; ?>
                <h1>Добро пожаловать <?php echo e($user->name); ?></h1>
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="dashboard-item">
                            <div class="num"><?php echo e($user->count()); ?></div>
                            <h5>Количество <br> пользователей</h5>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="dashboard-item">
                            <div class="num"><?php echo e($books->count()); ?></div>
                            <h5>Количество <br> бронирований</h5>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dashboard-item">
                            <div class="num"><?php echo e($rooms->count()); ?></div>
                            <h5>Количество <br> номеров</h5>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dashboard-item">
                            <div class="num"><?php echo e($travel->count()); ?></div>
                            <h5>Количество <br> экскурсий</h5>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dashboard-item">
                            <div class="num"><?php echo e($page->count()); ?></div>
                            <h5>Количество <br> страниц</h5>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/olimp-app/resources/views/auth/dashboard.blade.php ENDPATH**/ ?>