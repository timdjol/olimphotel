<?php $__env->startSection('title', 'Пользователи'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(session()->has('success')): ?>
                        <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
                    <?php endif; ?>
                    <?php if(session()->has('warning')): ?>
                        <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-md-7">
                            <h1>Пользователи</h1>
                        </div>
                        <div class="col-md-5">
                            <a class="btn add" href="<?php echo e(route('users.create')); ?>">Добавить</a>
                        </div>
                    </div>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Email</th>
                            <th>ФИО</th>
                            <th>Роль</th>
                            <th>Действия</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td>
                                    <?php if($user->is_admin == 1): ?>
                                        Администратор
                                    <?php elseif($user->is_admin == 2): ?>
                                        Менеджер
                                    <?php elseif($user->is_admin == 3): ?>
                                        Бухгалтер
                                    <?php elseif($user->is_admin == 4): ?>
                                        Менеджер Отеля
                                    <?php else: ?>
                                        Пользователь
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('users.destroy', $user)); ?>" method="post">
                                        <ul>
                                            <li><a class="btn view" href="<?php echo e(route('users.show', $user)); ?>">Открыть</a></li>
                                            <li><a class="btn edit" href="<?php echo e(route('users.edit', $user)); ?>">Редактировать</a></li>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn delete">Удалить</button>
                                        </ul>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($users->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/users/index.blade.php ENDPATH**/ ?>