<?php $__env->startSection('title', 'Главная страница'); ?>

<?php $__env->startSection('content'); ?>

    <div class="slider">
        <div class="owl-carousel owl-slider">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="slider-item" style="background-image: url(<?php echo e(Storage::url($slider->image)); ?>)"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="about">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="about-item">
                        <div class="img" style="background-image: url(<?php echo e(Storage::url($home->image)); ?>)"></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="about-item">
                        <div class="text-wrap">
                            <h2 data-aos="fade-up" data-aos-duration="2000"><?php echo app('translator')->get('main.about'); ?></h2>
                            <?php echo $home->__('description'); ?>

                            <div class="btn-wrap" data-aos="fade-up" data-aos-duration="2000">
                                <a href="<?php echo e(route('about')); ?>" class="more"><?php echo app('translator')->get('main.more'); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="vantage">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 data-aos="fade-up" data-aos-duration="2000"><?php echo app('translator')->get('main.vantages'); ?></h2>
                </div>
            </div>
            <div class="row justify-content-center">
                <?php $__currentLoopData = $vantages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vantage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-4 col-6">
                        <div class="vantage-item" data-aos="zoom-in" data-aos-duration="2000">
                            <img src="<?php echo e(Storage::url($vantage->image)); ?>" alt="">
                            <h5><?php echo e($vantage->__('title')); ?></h5>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="rooms">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 data-aos="fade-up" data-aos-duration="2000"><?php echo app('translator')->get('main.rooms'); ?></h2>
                </div>
            </div>
            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($loop->iteration % 2): ?>
                    <div class="row rooms-item">
                        <div class="col-md-6" data-aos="fade-right" data-aos-duration="2000">
                            <a href="<?php echo e(route('room', $room->code)); ?>">
                                <div class="img" style="background-image: url(<?php echo e(Storage::url($room->image)); ?>)"></div>
                            </a>
                        </div>
                        <div class="col-md-6" data-aos="fade-left" data-aos-duration="2000">
                            <h3><?php echo e($room->__('title')); ?></h3>
                            <?php echo $room->__('description'); ?>

                            <div class="btn-wrap">
                                <a href="<?php echo e(route('room', $room->code)); ?>" class="more"><?php echo app('translator')->get('main.more'); ?></a>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="row rooms-item second">
                        <div class="col-md-6 order-lg-1 order-md-1 order-2" data-aos="fade-right" data-aos-duration="2000">
                            <div class="text-wrap">
                                <h3><?php echo e($room->__('title')); ?></h3>
                                <?php echo $room->__('description'); ?>

                                <div class="btn-wrap">
                                    <a href="<?php echo e(route('room', $room->code)); ?>" class="more"><?php echo app('translator')->get('main.more'); ?></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 order-lg-2 order-md-2 order-1" data-aos="fade-left" data-aos-duration="2000">
                            <a href="<?php echo e(route('room', $room->code)); ?>">
                                <div class="img" style="background-image: url(<?php echo e(Storage::url($room->image)); ?>)"></div>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/olimp-app/resources/views/index.blade.php ENDPATH**/ ?>