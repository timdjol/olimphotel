<table>
    <tr>
        <td><?php echo app('translator')->get('main.name'); ?></td>
        <td><?php echo e($user->name); ?></td>
    </tr>
    <tr>
        <td><?php echo app('translator')->get('main.phone'); ?></td>
        <td><a href="tel:<?php echo e($user->phone); ?>"><?php echo e($user->phone); ?></a></td>
    </tr>
    <tr>
        <td>Email</td>
        <td><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></td>
    </tr>
    <tr>
        <td><?php echo app('translator')->get('main.message'); ?></td>
        <td><?php echo e($user->message); ?></td>
    </tr>
</table>

<style>
    table{
        width: 100%;
    }
    table td{
        padding: 10px;
        border-top: 1px solid #ddd;
    }
</style><?php /**PATH /Users/timdjol/Sites/localhost/olimp-app/resources/views/mail/contact.blade.php ENDPATH**/ ?>