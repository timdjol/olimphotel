<div class="sidebar">
    <ul>
        <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
            <li <?php echo Route::currentRouteNamed('dashboard') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('dashboard')); ?>">Консоль</a></li>
            <li <?php echo Route::currentRouteNamed('home') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('home')); ?>">Главная</a></li>
            <li <?php echo Route::currentRouteNamed('pages.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('pages.index')); ?>">Страницы</a></li>
            <li <?php echo Route::currentRouteNamed('bookings.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('bookings.index')); ?>">Бронирование</a></li>
            <li <?php echo Route::currentRouteNamed('rooms.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('rooms.index')); ?>">Номера</a></li>
            <li <?php echo Route::currentRouteNamed('travel.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('travel.index')); ?>">Экскурсии</a></li>
            <li <?php echo Route::currentRouteNamed('orders.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('orders.index')); ?>">Заявки с Экскурсии</a></li>
            <li <?php echo Route::currentRouteNamed('rents.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('rents.index')); ?>">Виды туров</a></li>
            <li <?php echo Route::currentRouteNamed('contacts.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('contacts.index')); ?>">Контакты</a></li>
            <li <?php echo Route::currentRouteNamed('profile.edit') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('profile.edit')); ?>">Профиль</a></li>
        <?php else: ?>
            <li <?php echo Route::currentRouteNamed('person.orders.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('person.orders.index')); ?>">Заказы</a></li>
            <li><a href="<?php echo e(route('profile.edit')); ?>">Профиль</a></li>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH /Users/timdjol/Sites/localhost/olimp-app/resources/views/auth/layouts/sidebar.blade.php ENDPATH**/ ?>