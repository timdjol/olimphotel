<?php $__env->startSection('title', 'Контакты'); ?>

<?php $__env->startSection('content'); ?>

    <div class="pagetitle" style="background-image: url(<?php echo e(url('/')); ?>/img/111.jpg)">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 data-aos="fade-up" data-aos-duration="2000"><?php echo e($page->__('title')); ?></h1>
                    <ul class="breadcrumbs">
                        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                        <li>></li>
                        <li><?php echo e($page->__('title')); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="page contacts pt0">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 col-md-12">
                    <script src="https://maps.api.2gis.ru/2.0/loader.js"></script>
                    <div id="map" style="width: 100%; height: 450px;"></div>
                    <script>
                        DG.then(function () {
                            var map = DG.map('map', {
                                center: [42.6512993, 77.1130353],
                                zoom: 14
                            });

                            DG.marker([42.6512993, 77.1130353], { scrollWheelZoom: false })
                                .addTo(map)
                                .bindLabel('OlimpHotel&Travel', {
                                    static: true
                                });
                        });
                    </script>
                    <?php echo $page->__('description'); ?>

                    <form action="<?php echo e(route('contact_mail')); ?>" method="post">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input type="text" name="name" placeholder="<?php echo app('translator')->get('main.name'); ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input type="email" name="email" placeholder="Email" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input type="text" name="phone" id="phone" placeholder="<?php echo app('translator')->get('main.phone'); ?>"
                                           required>
                                    <div id="output"></div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <textarea name="message" rows="4" placeholder="<?php echo app('translator')->get('main.message'); ?>"></textarea>
                                <?php echo csrf_field(); ?>
                                <button class="more" id="send"><?php echo app('translator')->get('main.send'); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/olimp-app/resources/views/pages/contacts.blade.php ENDPATH**/ ?>