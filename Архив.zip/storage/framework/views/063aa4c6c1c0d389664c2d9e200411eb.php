<?php $__env->startSection('title', 'Бронирование'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <h1>Бронирование</h1>
                    <table>
                        <tr>
                            <th>Отель</th>
                            <th>Номер</th>
                            <th>ФИО</th>
                            <th>Телефон</th>
                            <th>Email</th>
                            <th>Кол-во</th>
                            <th>Сумма</th>
                            <th>Дата заезда</th>
                            <th>Дата выезда</th>
                        </tr>
                        <tbody>
                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php
                                        $hotel = \App\Models\Hotel::where('id', $booking->hotel_id)->firstOrFail();
                                    ?>
                                    <?php echo e($hotel->title); ?>

                                </td>
                                <td>
                                    <?php
                                        $room = \App\Models\Room::where('id', $booking->room_id)->firstOrFail();
                                    ?>
                                    <?php echo e($room->title); ?>

                                </td>
                                <td><?php echo e($booking->title); ?></td>
                                <td><a href="tel:<?php echo e($booking->phone); ?>"><?php echo e($booking->phone); ?></a></td>
                                <td><a href="mailto:<?php echo e($booking->email); ?>"><?php echo e($booking->email); ?></a></td>
                                <td><?php echo e($booking->count); ?></td>
                                <td><?php echo e($booking->sum); ?></td>
                                <td><?php echo e($booking->showStartDate()); ?></td>
                                <td><?php echo e($booking->showEndDate()); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <style>
        table th, table td {
            font-size: 14px;
            line-height: 1.2;
        }

        table a {
            color: #0163b4;
            text-decoration: none;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/buh/books/index.blade.php ENDPATH**/ ?>