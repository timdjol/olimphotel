<?php $__env->startSection('title', 'Забыли пароль?'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3 col-md-12">
                    <h3>Восстановление пароля</h3>
                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="">Email</label>
                            <input type="email" name="email">
                        </div>
                        <button class="more">Отправить</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/forgot-password.blade.php ENDPATH**/ ?>