<!DOCTYPE html>
<html lang="ru">

<head>

    <meta charset="utf-8">
    <!-- <base href="/"> -->

    <title><?php echo $__env->yieldContent('title'); ?> - SilkWayTravel</title>
    <meta name="description" content="">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Template Basic Images Start -->
    <meta property="og:image" content="path/to/image.jpg">
    <link rel="icon" href="<?php echo e(route('index')); ?>/img/favicon.png">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(route('index')); ?>/img/favicon.png">
    <!-- Template Basic Images End -->

    <!-- Custom Browsers Color Start -->
    <meta name="theme-color" content="#000">
    <!-- Custom Browsers Color End -->

    <link rel="stylesheet" href="<?php echo e(route('index')); ?>/css/main.min.css">
    <link rel="stylesheet" href="<?php echo e(route('index')); ?>/css/style.css">


    <script src="<?php echo e(route('index')); ?>/js/scripts.min.js"></script>

</head>

<body>
<header>
    <div class="container">
        <div class="row">
            <div class="col-lg-2 col-md-4 col-6">
                <div class="logo">
                    <a href="<?php echo e(route('homepage')); ?>"><img src="<?php echo e(url('/')); ?>/img/logo.png" alt=""></a>
                </div>
            </div>
            <div class="col-lg-10 col-md-8 col-6">
                <ul class="lang d-xl-none d-lg-none d-inline-block">
                    <li class="
                            <?php if(session('locale')=='ru'): ?>
                                current
                            <?php endif; ?>
                            "><a href="<?php echo e(route('locale', 'ru')); ?>">RU</a></li>
                    <li class="
                            <?php if(session('locale')=='en'): ?>
                                current
                            <?php endif; ?>
                            "><a href="<?php echo e(route('locale', 'en')); ?>">EN</a></li>
                </ul>
                <nav>
                    <a href="#" class="toggle-mnu d-xl-none d-lg-none"><span></span></a>
                    <ul>
                        <li <?php echo Route::currentRouteNamed('homepage') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('homepage')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                        <li <?php echo Route::currentRouteNamed('hotels') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('hotels')); ?>"><?php echo app('translator')->get('main.hotels'); ?></a></li>
                        <li <?php echo Route::currentRouteNamed('allrooms') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('allrooms')); ?>"><?php echo app('translator')->get('main.rooms'); ?></a></li>
                        <li <?php echo Route::currentRouteNamed('about') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('about')); ?>"><?php echo app('translator')->get('main.about'); ?></a></li>
                        <li <?php echo Route::currentRouteNamed('contactspage') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('contactspage')); ?>"><?php echo app('translator')->get('main.contacts'); ?>
                        </a></li>
                    </ul>
                    <ul class="lang d-xl-inline-block d-lg-inline-block d-none">
                        <li class="
                            <?php if(session('locale')=='ru'): ?>
                                current
                            <?php endif; ?>
                            "><a href="<?php echo e(route('locale', 'ru')); ?>">RU</a></li>
                        <li class="
                            <?php if(session('locale')=='en'): ?>
                                current
                            <?php endif; ?>
                            "><a href="<?php echo e(route('locale', 'en')); ?>">EN</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header>


<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(session()->has('success')): ?>
                <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
            <?php endif; ?>
            <?php if(session()->has('warning')): ?>
                <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php echo $__env->yieldContent('content'); ?>

<footer>
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-6">
                    <div class="footer-item">
                        <div class="logo"><img src="<?php echo e(url('/')); ?>/img/logo.png" alt=""></div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="footer-item">
                        <h4><?php echo app('translator')->get('main.hotels'); ?></h4>
                        <ul>
                            <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('hotel', $hotel->code)); ?>"><?php echo e($hotel->__('title')); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="footer-item">
                        <h4><?php echo app('translator')->get('main.navigation'); ?></h4>
                        <ul>
                            <li <?php echo Route::currentRouteNamed('hotels') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('hotels')); ?>"><?php echo app('translator')->get('main.hotels'); ?></a></li>
                            <li <?php echo Route::currentRouteNamed('allrooms') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('allrooms')); ?>"><?php echo app('translator')->get('main.rooms'); ?></a></li>
                            <li <?php echo Route::currentRouteNamed('about') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('about')); ?>"><?php echo app('translator')->get('main.about'); ?></a></li>
                            <li <?php echo Route::currentRouteNamed('contactspage') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('contactspage')); ?>"><?php echo app('translator')->get('main.contacts'); ?>
                            </a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="footer-item">
                        <h4><?php echo app('translator')->get('main.contacts'); ?></h4>
                        <ul>
                            <li><?php echo e($contacts->first()->__('address')); ?></li>
                            <li><a href="tel:<?php echo e($contacts->first()->phone); ?>"><?php echo e($contacts->first()->phone); ?></a></li>
                            <li><a href="tel:<?php echo e($contacts->first()->phone2); ?>"><?php echo e($contacts->first()->phone2); ?></a></li>
                        </ul>
                        <ul class="soc">
                            <li><a href="<?php echo e($contacts->first()->instagram); ?>" target="_blank"><img
                                            src="<?php echo e(route('index')); ?>/img/instagram.svg" alt=""></a>
                            </li>
                            <li><a href="https://wa.me/<?php echo e($contacts->first()->whatsapp); ?>" target="_blank"><img
                                            src="<?php echo e(route('index')); ?>/img/whatsapp.svg" alt=""></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copy">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p><?php echo app('translator')->get('main.copy'); ?> &copy; <?php echo e(date('Y')); ?> silkwaytravel.kg</p>
                </div>
            </div>
        </div>
    </div>
</footer>





</body>

</html>

<?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/layouts/master.blade.php ENDPATH**/ ?>