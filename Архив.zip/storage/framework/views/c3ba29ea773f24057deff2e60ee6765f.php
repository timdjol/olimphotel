<div class="sidebar">
    <div class="logo">
        <a href="<?php echo e(route('dashboard')); ?>"><img src="<?php echo e(url('/')); ?>/img/logo.png" alt=""></a>
    </div>
    <ul>
        <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
            <li <?php echo Route::currentRouteNamed('dashboard') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('dashboard')); ?>">Консоль</a></li>
            <li <?php echo Route::currentRouteNamed('bookings.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('bookings.index')); ?>">Бронирование</a></li>
            <li <?php echo Route::currentRouteNamed('statuses.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('statuses.index')); ?>">Статусы бронирования</a></li>
            <li <?php echo Route::currentRouteNamed('hotels.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('hotels.index')); ?>">Отели</a></li>
            <li <?php echo Route::currentRouteNamed('rooms.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('rooms.index')); ?>">Номера</a></li>
            <li <?php echo Route::currentRouteNamed('users.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('users.index')); ?>">Пользователи</a></li>
            <li <?php echo Route::currentRouteNamed('pages.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('pages.index')); ?>">Страницы</a></li>
            <li <?php echo Route::currentRouteNamed('home') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('home')); ?>">Главная</a></li>
            <li <?php echo Route::currentRouteNamed('contacts.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('contacts.index')); ?>">Контакты</a></li>
            <li <?php echo Route::currentRouteNamed('profile.edit') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('profile.edit')); ?>">Профиль</a></li>
        <?php endif; ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('manager')): ?>
            <li <?php echo Route::currentRouteNamed('manager.dashboard') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('manager.dashboard')); ?>">Консоль</a></li>
            <li <?php echo Route::currentRouteNamed('manager.books.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('manager.books.index')); ?>">Бронирование</a></li>
            <li <?php echo Route::currentRouteNamed('manager.hotels.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('manager.hotels.index')); ?>">Отели</a></li>
            <li <?php echo Route::currentRouteNamed('manager.rooms.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('manager.rooms.index')); ?>">Номера</a></li>
            <li <?php echo Route::currentRouteNamed('manager.users.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('manager.users.index')); ?>">Пользователи</a></li>
            <li <?php echo Route::currentRouteNamed('manager.pages.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('manager.pages.index')); ?>">Страницы</a></li>
            <li <?php echo Route::currentRouteNamed('manager.contacts.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('manager.contacts.index')); ?>">Контакты</a></li>
            <li><a href="<?php echo e(route('profile.edit')); ?>">Профиль</a></li>
        <?php endif; ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('buh')): ?>
            <li <?php echo Route::currentRouteNamed('buh.dashboard') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('buh.dashboard')); ?>">Консоль</a></li>
            <li <?php echo Route::currentRouteNamed('buh.books.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('buh.books.index')); ?>">Бронирование</a></li>
            <li <?php echo Route::currentRouteNamed('buh.hotels.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('buh.hotels.index')); ?>">Отели</a></li>
            <li <?php echo Route::currentRouteNamed('buh.rooms.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('buh.rooms.index')); ?>">Номера</a></li>
            <li><a href="<?php echo e(route('profile.edit')); ?>">Профиль</a></li>
        <?php endif; ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('hotel')): ?>
            <li <?php echo Route::currentRouteNamed('hotel.dashboard') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('hotel.dashboard')); ?>">Консоль</a></li>
            <li <?php echo Route::currentRouteNamed('hotel.books.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('hotel.books.index')); ?>">Бронирование</a></li>
            <li <?php echo Route::currentRouteNamed('hotel.hotels.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('hotel.hotels.index')); ?>">Отели</a></li>
            <li <?php echo Route::currentRouteNamed('hotel.rooms.index') ? 'class="current"' : ''  ?>><a href="<?php echo e(route('hotel.rooms.index')); ?>">Номера</a></li>
            <li><a href="<?php echo e(route('profile.edit')); ?>">Профиль</a></li>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/layouts/sidebar.blade.php ENDPATH**/ ?>