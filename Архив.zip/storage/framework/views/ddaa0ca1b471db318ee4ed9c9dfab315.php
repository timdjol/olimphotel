<?php $__env->startSection('title', 'Об отеле'); ?>

<?php $__env->startSection('content'); ?>

    <div class="pagetitle" style="background-image: url(<?php echo e(Storage::url($page->image)); ?>)">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 data-aos="fade-up" data-aos-duration="2000"><?php echo e($page->__('title')); ?></h1>
                    <ul class="breadcrumbs">
                        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                        <li>></li>
                        <li><?php echo e($page->__('title')); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="page about">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 col-md-12">
                    <?php echo $page->__('description'); ?>

                </div>
            </div>
        </div>
    </div>

    <div class="vantage">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 data-aos="fade-up" data-aos-duration="2000"><?php echo app('translator')->get('main.vantages'); ?></h2>
                </div>
            </div>
            <div class="row justify-content-center">
                <?php $__currentLoopData = $vantages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vantage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-4 col-6">
                        <div class="vantage-item" data-aos="zoom-in" data-aos-duration="2000">
                            <img src="<?php echo e(Storage::url($vantage->image)); ?>" alt="">
                            <h5><?php echo e($vantage->__('title')); ?></h5>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="page about">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 col-md-12">
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="faq-item">
                            <button class="accordion"><?php echo e($faq->__('title')); ?></button>
                            <div class="accordion-content">
                                <?php echo $faq->__('description'); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="gallery">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="gallery-item" data-aos="zoom-in" data-aos-duration="2000">
                        <a href="img/1.jpg"><div class="img" style="background-image: url(img/1.jpg)"></div></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="gallery-item" data-aos="zoom-in" data-aos-duration="2000">
                        <a href="img/3.jpg"><div class="img" style="background-image: url(img/3.jpg)"></div></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="gallery-item" data-aos="zoom-in" data-aos-duration="2000">
                        <a href="img/1.jpg"><div class="img" style="background-image: url(img/1.jpg)"></div></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="gallery-item" data-aos="zoom-in" data-aos-duration="2000">
                        <a href="img/4.jpg"><div class="img" style="background-image: url(img/4.jpg)"></div></a>
                    </div>
                </div>

                <div class="col-lg-3 col-md-4 col-6">
                    <div class="gallery-item" data-aos="zoom-in" data-aos-duration="2000">
                        <a href="img/6.jpg"><div class="img" style="background-image: url(img/6.jpg)"></div></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="gallery-item" data-aos="zoom-in" data-aos-duration="2000">
                        <a href="img/5.jpg"><div class="img" style="background-image: url(img/5.jpg)"></div></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="gallery-item" data-aos="zoom-in" data-aos-duration="2000">
                        <a href="img/8.jpg"><div class="img" style="background-image: url(img/8.jpg)"></div></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="gallery-item" data-aos="zoom-in" data-aos-duration="2000">
                        <a href="img/7.jpg"><div class="img" style="background-image: url(img/7.jpg)"></div></a>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/olimp-app/resources/views/pages/about.blade.php ENDPATH**/ ?>