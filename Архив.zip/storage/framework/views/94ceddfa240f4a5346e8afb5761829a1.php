<?php $__env->startSection('title', 'Консоль'); ?>

<?php $__env->startSection('content'); ?>

<div class="page admin statistic">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <?php echo $__env->make('auth/layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-9">
                <?php if(session()->has('success')): ?>
                    <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
                <?php endif; ?>
                <?php if(session()->has('warning')): ?>
                    <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
                <?php endif; ?>
                <h1>Добро пожаловать <?php echo e($users->name); ?></h1>
                    <div class="position">Роль:
                        <?php if($users->is_admin == 1): ?>
                            Администратор
                        <?php elseif($users->is_admin == 2): ?>
                            Менеджер
                        <?php elseif($users->is_admin == 3): ?>
                            Бухгалтер
                        <?php elseif($users->is_admin == 4): ?>
                            Менеджер Отеля
                        <?php else: ?>
                            Пользователь
                        <?php endif; ?>
                    </div>
                    <h3>Статистика</h3>
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="statistic-item">
                            <h4>Количество <br> бронирований</h4>
                            <div class="num"><?php echo e($books->count()); ?></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="statistic-item">
                            <h4>Количество <br> отелей</h4>
                            <div class="num"><?php echo e($hotels->count()); ?></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="statistic-item">
                            <h4>Количество <br> номеров</h4>
                            <div class="num"><?php echo e($rooms->count()); ?></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="statistic-item">
                            <h4>Количество <br> страниц</h4>
                            <div class="num"><?php echo e($pages->count()); ?></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="statistic-item">
                            <h4>Количество <br> пользователей</h4>
                            <div class="num"><?php echo e($users->count()); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/dashboard.blade.php ENDPATH**/ ?>