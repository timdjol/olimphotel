<h2>Удаление аккаунта</h2>
<form method="post" action="<?php echo e(route('profile.destroy')); ?>" class="p-6">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
    <h4>Вы уверены, что хотите удалить аккаунт?</h4>
    <p>После удаления вашей учетной записи все ее ресурсы и данные будут безвозвратно удалены. Пожалуйста, введите свой
        пароль, чтобы подтвердить, что вы хотите навсегда удалить свою учетную запись.</p>

    <div class="form-group">
        <label for="">Пароль</label>
        <input type="password" name="password" value="<?php echo e(__('Password')); ?>">
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->userDeletion->get('password'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->userDeletion->get('password')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
    <button class="more">Удалить аккаунт</button>
</form>

<style>
    h2{
        margin-top: 40px;
    }
</style>

<?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/profile/partials/delete-user-form.blade.php ENDPATH**/ ?>