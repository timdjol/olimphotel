<?php $__env->startSection('title', 'Бронирование'); ?>

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css" rel="stylesheet" />
    <div class="page admin book">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(session()->has('success')): ?>
                        <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
                    <?php endif; ?>
                    <?php if(session()->has('warning')): ?>
                        <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
                    <?php endif; ?>
                        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
                        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
                        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.css" />
                        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
                        <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.js"></script>
                            <h1>Бронирование</h1>
                            <div class="icons">
                                <div class="icon free">- Свободно</div>
                                <div class="icon busy">- Занято</div>
                            </div>
                            <div id="calendar"></div>
                        <script>

                            $(document).ready(function () {

                                $.ajaxSetup({
                                    headers:{
                                        'X-CSRF-TOKEN' : $('meta[name="csrf-token"]').attr('content')
                                    }
                                });

                                var calendar = $('#calendar').fullCalendar({
                                    editable:true,
                                    header:{
                                        left:'prev,next today',
                                        center:'title',
                                        right:'month,agendaWeek,agendaDay'
                                    },
                                    events:'/books',
                                    selectable:true,
                                    selectHelper: true,
                                    select:function(start, end, allDay)
                                    {
                                        var title = prompt('Event Title:');

                                        if(title)
                                        {
                                            var start = $.fullCalendar.formatDate(start, 'Y-MM-DD HH:mm:ss');

                                            var end = $.fullCalendar.formatDate(end, 'Y-MM-DD HH:mm:ss');

                                            $.ajax({
                                                url:"/books/action",
                                                type:"POST",
                                                data:{
                                                    title: title,
                                                    start: start,
                                                    end: end,
                                                    type: 'add'
                                                },
                                                success:function(data)
                                                {
                                                    calendar.fullCalendar('refetchEvents');
                                                    alert("Event Created Successfully");
                                                }
                                            })
                                        }
                                    },
                                    editable:true,
                                    eventResize: function(event, delta)
                                    {
                                        var start = $.fullCalendar.formatDate(event.start, 'Y-MM-DD HH:mm:ss');
                                        var end = $.fullCalendar.formatDate(event.end, 'Y-MM-DD HH:mm:ss');
                                        var title = event.title;
                                        var id = event.id;
                                        $.ajax({
                                            url:"/books/action",
                                            type:"POST",
                                            data:{
                                                title: title,
                                                start: start,
                                                end: end,
                                                id: id,
                                                type: 'update'
                                            },
                                            success:function(response)
                                            {
                                                calendar.fullCalendar('refetchEvents');
                                                alert("Event Updated Successfully");
                                            }
                                        })
                                    },
                                    eventDrop: function(event, delta)
                                    {
                                        var start = $.fullCalendar.formatDate(event.start, 'Y-MM-DD HH:mm:ss');
                                        var end = $.fullCalendar.formatDate(event.end, 'Y-MM-DD HH:mm:ss');
                                        var title = event.title;
                                        var id = event.id;
                                        $.ajax({
                                            url:"/books/action",
                                            type:"POST",
                                            data:{
                                                title: title,
                                                start: start,
                                                end: end,
                                                id: id,
                                                type: 'update'
                                            },
                                            success:function(response)
                                            {
                                                calendar.fullCalendar('refetchEvents');
                                                alert("Event Updated Successfully");
                                            }
                                        })
                                    },

                                    eventClick:function(event)
                                    {
                                        if(confirm("Are you sure you want to remove it?"))
                                        {
                                            var id = event.id;
                                            $.ajax({
                                                url:"/books/action",
                                                type:"POST",
                                                data:{
                                                    id:id,
                                                    type:"delete"
                                                },
                                                success:function(response)
                                                {
                                                    calendar.fullCalendar('refetchEvents');
                                                    alert("Event Deleted Successfully");
                                                }
                                            })
                                        }
                                    }
                                });

                            });

                        </script>

                        </div>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/olimp-app/resources/views/auth/boo22ks/index.blade.php ENDPATH**/ ?>