<?php $__env->startSection('title', 'Пользователь ' . $user->name); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <h1>Пользователи</h1>
                    <table>
                        <tr>
                            <th>ФИО</th>
                            <td><?php echo e($user->name); ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?php echo e($user->email); ?></td>
                        </tr>
                        <tr>
                            <th>Роль пользователя</th>
                            <td>
                                <?php if($user->is_admin == 1): ?>
                                    Администратор
                                <?php elseif($user->is_admin == 2): ?>
                                    Менеджер
                                <?php elseif($user->is_admin == 3): ?>
                                    Бухгалтер
                                <?php elseif($user->is_admin == 4): ?>
                                    Менеджер Отеля
                                <?php else: ?>
                                    Пользователь
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/silkway-app/resources/views/auth/users/show.blade.php ENDPATH**/ ?>